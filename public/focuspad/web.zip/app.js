const KEY = "focuspad.web.v1";
const CIRC = 2 * Math.PI * 86;
const WEB_VERSION = 49;
const DEFAULT_UPDATE_URL =
  "https://raw.githubusercontent.com/liudiyuan404/hellodiyuan/main/public/focuspad/";
const DAY_START = 7 * 60;
const DAY_END = 23 * 60;
const DAY_SPAN = DAY_END - DAY_START;
const PALETTE = {
  amber: { rgb: "201 134 42", name: "琥珀" },
  moss: { rgb: "74 124 89", name: "苔绿" },
  pine: { rgb: "46 102 84", name: "松绿" },
  lake: { rgb: "56 112 128", name: "湖青" },
  clay: { rgb: "176 92 64", name: "陶土" },
  plum: { rgb: "122 86 110", name: "梅紫" },
  sand: { rgb: "168 132 72", name: "沙金" },
  slate: { rgb: "90 104 98", name: "青灰" },
};
const PALETTE_IDS = Object.keys(PALETTE);
const DEFAULT_SUBJECT_COLOR = { en: "lake", math: "clay", other: "amber" };
const DEMO_SEED_VER = "v1";

const defaultState = () => ({
  lists: [
    { id: "inbox", name: "收集箱", system: "inbox" },
    { id: "today", name: "今天", system: "today" },
  ],
  subjects: [
    { id: "en", name: "英语", minutes: 25, color: "lake" },
    { id: "math", name: "数学", minutes: 25, color: "clay" },
    { id: "other", name: "其他", minutes: 25, color: "amber" },
  ],
  tasks: [],
  sessions: [],
  plans: [],
  planChecks: [],
  settings: {
    focusMinutes: 25,
    shortBreakMinutes: 5,
    longBreakMinutes: 15,
    cyclesBeforeLongBreak: 4,
    dailyGoal: 8,
    themeMode: "system",
    updateUrl: DEFAULT_UPDATE_URL,
    autoUpdate: true,
    githubToken: "",
    gistId: "",
    syncDevice: "tablet",
    lastSyncAt: 0,
  },
  syncTombs: { tasks: [], sessions: [], plans: [], planChecks: [], lists: [], subjects: [] },
  timer: idleTimer("countdown", "focus", 25 * 60, "en", "英语"),
  ui: {
    tab: "today",
    selectedListId: "inbox",
    statsPeriod: "day",
    statsDate: dayKey(new Date()),
    scheduleDate: dayKey(new Date()),
    scheduleView: "day",
    listsOpen: false,
    timerFull: false,
    modal: null,
    banner: "",
    demoSeeded: "",
    updateStatus: "",
  },
});

function idleTimer(mode, kind, targetSec, subjectId, subjectName) {
  return {
    mode,
    kind,
    run: "idle",
    targetSec,
    elapsedSec: 0,
    endAt: null,
    startedAt: null,
    resumeAt: null,
    subjectId,
    subjectName,
    taskId: null,
    taskTitle: null,
    completedFocus: 0,
  };
}

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
}

const RECORD_KEYS = ["lists", "subjects", "tasks", "sessions", "plans", "planChecks"];
const recordCores = {
  lists: new Map(),
  subjects: new Map(),
  tasks: new Map(),
  sessions: new Map(),
  plans: new Map(),
  planChecks: new Map(),
};
let cloudBusy = false;
let cloudDirty = false;
let cloudTimer = 0;
let skipCloud = 0;
let cloudTabletSeeded = false;
let cloudTabletSeedRev = 0;

function itemCore(item) {
  if (!item || typeof item !== "object") return "";
  const copy = { ...item };
  delete copy.updatedAt;
  return JSON.stringify(copy);
}

function itemTime(item) {
  return Number(item?.updatedAt || item?.endedAt || item?.completedAt || item?.createdAt || 0);
}

function rememberRecordCores() {
  for (const key of RECORD_KEYS) {
    recordCores[key] = new Map(
      (state[key] || []).filter((item) => item?.id).map((item) => [item.id, itemCore(item)]),
    );
  }
}

function stampChangedRecords() {
  const now = Date.now();
  for (const key of RECORD_KEYS) {
    const prev = recordCores[key] || new Map();
    const next = new Map();
    state[key] = (state[key] || []).map((item) => {
      if (!item?.id) return item;
      const core = itemCore(item);
      const old = prev.get(item.id);
      next.set(item.id, core);
      if (old !== undefined && old !== core) return { ...item, updatedAt: now };
      return item;
    });
    recordCores[key] = next;
  }
}

function sameId(a, b) {
  return String(a || "") !== "" && String(a) === String(b);
}

function tombId(row) {
  const id = typeof row === "string" ? row : row?.id;
  return id == null || id === "" ? "" : String(id);
}

function tombAt(row) {
  return typeof row === "string" ? 0 : Number(row?.at || 0);
}

function tombMap(rows) {
  const map = new Map();
  for (const row of rows || []) {
    const id = tombId(row);
    if (!id) continue;
    map.set(id, Math.max(map.get(id) || 0, tombAt(row)));
  }
  return map;
}

function hasUserRecords(next = state) {
  return RECORD_KEYS.some((key) => key !== "lists" && key !== "subjects" && (next[key] || []).length > 0);
}

function sanitizeState(next) {
  const fallback = defaultState();
  for (const key of RECORD_KEYS) {
    if (!Array.isArray(next[key])) next[key] = fallback[key];
    next[key] = next[key].filter((item) => item && typeof item === "object" && item.id);
  }
  if (!next.lists.length) next.lists = fallback.lists.map((item) => ({ ...item }));
  if (!next.subjects.length) next.subjects = fallback.subjects.map((item) => ({ ...item }));
  if (!next.settings || typeof next.settings !== "object") next.settings = fallback.settings;
  if (!next.ui || typeof next.ui !== "object") next.ui = fallback.ui;
  if (!next.timer || typeof next.timer !== "object") next.timer = fallback.timer;
  if (!next.syncTombs || typeof next.syncTombs !== "object") next.syncTombs = fallback.syncTombs;
  return next;
}

function isLocalUpdateUrl(url) {
  try {
    const host = new URL(url).hostname;
    return (
      host === "localhost" ||
      host === "127.0.0.1" ||
      host.endsWith(".local") ||
      host.startsWith("10.") ||
      host.startsWith("192.168.") ||
      host.startsWith("172.20.") ||
      /^172\.(1[6-9]|2\d|3[01])\./.test(host)
    );
  } catch {
    return false;
  }
}

function resolvedUpdateUrl(url = state?.settings?.updateUrl) {
  const trimmed = String(url || "").trim();
  if (!trimmed || isLocalUpdateUrl(trimmed)) return DEFAULT_UPDATE_URL;
  return trimmed;
}

function load() {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    const next = {
      ...defaultState(),
      ...parsed,
      settings: {
        ...defaultState().settings,
        ...(parsed.settings || {}),
      },
      ui: {
        ...defaultState().ui,
        ...(parsed.ui || {}),
        modal: null,
        listsOpen: false,
        banner: "",
        statsDate: dayKey(),
        statsPeriod: "day",
      },
    };
    next.settings.updateUrl = resolvedUpdateUrl(next.settings.updateUrl);
    return sanitizeState(next);
  } catch {
    return defaultState();
  }
}

function dayKey(date = new Date()) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function parseDayKey(key) {
  const [y, m, d] = String(key || dayKey()).split("-").map(Number);
  return new Date(y, (m || 1) - 1, d || 1);
}

function minutesOf(date) {
  return date.getHours() * 60 + date.getMinutes();
}

function formatHm(min) {
  const safe = Math.max(0, Math.min(24 * 60, Math.round(min)));
  const h = Math.floor(safe / 60);
  const m = safe % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}

function parseHm(value) {
  const [h, m] = String(value || "09:00").split(":");
  return Number(h || 0) * 60 + Number(m || 0);
}

function snapMinutes(min, step = 30) {
  return Math.round(min / step) * step;
}

function modalTime(name, fallback) {
  const draft = state.ui.modal?.time?.[name];
  return draft ? formatHm(parseHm(draft)) : formatHm(parseHm(fallback));
}

function timeWheelHtml(name, value) {
  const total = Math.min(23 * 60 + 59, parseHm(value));
  const picked = { hour: Math.floor(total / 60), minute: total % 60 };
  const column = (unit, count, label) => {
    const items = Array.from({ length: count }, (_, v) => {
      const on = v === picked[unit] ? " is-on" : "";
      return `<button type="button" class="wheel-item${on}" data-value="${v}" tabindex="-1">${String(v).padStart(2, "0")}</button>`;
    }).join("");
    return `<div class="wheel-pair">
      <div class="wheel-col" data-wheel="${unit}" aria-label="${label}">
        <div class="wheel-items">${items}</div>
      </div>
      <span class="wheel-unit" aria-hidden="true">${label}</span>
    </div>`;
  };
  return `<div class="time-wheel" data-time-wheel="${name}">
    <input type="hidden" name="${name}" value="${formatHm(total)}" />
    <div class="wheel-window">
      <div class="wheel-band" aria-hidden="true"></div>
      ${column("hour", 24, "时")}
      ${column("minute", 60, "分")}
    </div>
  </div>`;
}

function wheelRowHeight(col) {
  const item = col.querySelector(".wheel-item");
  const raw = item?.getBoundingClientRect?.().height || item?.offsetHeight || 0;
  return raw > 0 ? raw : 40;
}

function wheelIndex(col) {
  const rows = col.dataset.wheel === "hour" ? 24 : 60;
  return Math.max(0, Math.min(rows - 1, Math.round(col.scrollTop / wheelRowHeight(col))));
}

function readTimeWheel(wrap) {
  const value = { hour: 0, minute: 0 };
  wrap.querySelectorAll(".wheel-col").forEach((col) => {
    const index = wheelIndex(col);
    value[col.dataset.wheel] = index;
    col.querySelectorAll(".wheel-item").forEach((item, i) => {
      item.classList.toggle("is-on", i === index);
    });
  });
  return formatHm(value.hour * 60 + value.minute);
}

function commitTimeWheel(wrap) {
  const name = wrap.dataset.timeWheel;
  const next = readTimeWheel(wrap);
  const field = wrap.querySelector("input[type=hidden]");
  if (field) field.value = next;
  if (state.ui.modal) {
    state.ui.modal.time = { ...(state.ui.modal.time || {}), [name]: next };
    if (name === "start") state.ui.modal.startHm = next;
    if (name === "end") state.ui.modal.endHm = next;
  }
}

function flushTimeWheels(scope = root) {
  scope?.querySelectorAll("[data-time-wheel]").forEach((wrap) => {
    if (wrap.dataset.touched === "1") commitTimeWheel(wrap);
  });
}

function wheelTarget(wrap, col) {
  const total = parseHm(wrap.querySelector("input")?.value);
  const hour = Math.min(23, Math.floor(total / 60));
  const minute = total % 60;
  return col.dataset.wheel === "hour" ? hour : minute;
}

function placeTimeWheel(wrap) {
  wrap.querySelectorAll(".wheel-col").forEach((col) => {
    const start = wheelTarget(wrap, col);
    const top = start * wheelRowHeight(col);
    const snap = col.style.scrollSnapType;
    col.style.scrollSnapType = "none";
    col.scrollTop = top;
    col.style.scrollSnapType = snap;
    col.querySelectorAll(".wheel-item").forEach((item, i) => {
      item.classList.toggle("is-on", i === start);
    });
  });
}

function initTimeWheels() {
  root.querySelectorAll("[data-time-wheel]").forEach((wrap) => {
    if (wrap.dataset.ready === "1") {
      if (wrap.dataset.touched !== "1") placeTimeWheel(wrap);
      return;
    }
    wrap.dataset.ready = "1";
    wrap.querySelectorAll(".wheel-col").forEach((col) => {
      const snapTo = (index, smooth) => {
        const top = Math.max(0, index) * wheelRowHeight(col);
        if (Math.abs(col.scrollTop - top) < 1) return;
        if (smooth) col.scrollTo({ top, behavior: "smooth" });
        else col.scrollTop = top;
      };
      let settle = 0;
      col.addEventListener(
        "scroll",
        () => {
          if (wrap.dataset.locking === "1") return;
          wrap.dataset.touched = "1";
          readTimeWheel(wrap);
          window.clearTimeout(settle);
          settle = window.setTimeout(() => {
            snapTo(wheelIndex(col), true);
            commitTimeWheel(wrap);
          }, 90);
        },
        { passive: true },
      );
      col.addEventListener("click", (event) => {
        const item = event.target.closest(".wheel-item");
        if (!item) return;
        event.preventDefault();
        wrap.dataset.touched = "1";
        snapTo(Number(item.dataset.value), true);
        commitTimeWheel(wrap);
      });
    });
    wrap.dataset.locking = "1";
    let tries = 0;
    const place = () => {
      placeTimeWheel(wrap);
      const ok = [...wrap.querySelectorAll(".wheel-col")].every((col) => {
        const start = wheelTarget(wrap, col);
        return Math.abs(col.scrollTop - start * wheelRowHeight(col)) < 2;
      });
      if (!ok && tries++ < 12) {
        requestAnimationFrame(place);
        return;
      }
      wrap.dataset.locking = "0";
    };
    place();
  });
}

function defaultPlanStart(dateKey) {
  if (dateKey !== dayKey()) return 9 * 60;
  return Math.max(DAY_START, Math.min(DAY_END - 30, snapMinutes(minutesOf(new Date()) + 5)));
}

function dayPct(min) {
  return ((min - DAY_START) / DAY_SPAN) * 100;
}

const WEEKDAY_ORDER = [1, 2, 3, 4, 5, 6, 0];
const WEEKDAY_LABEL = ["日", "一", "二", "三", "四", "五", "六"];

function normalizeWeekdays(days) {
  return WEEKDAY_ORDER.filter((day) => (days || []).map(Number).includes(day));
}

function planRepeat(plan) {
  return plan?.repeat === "daily" || plan?.repeat === "weekly" ? plan.repeat : "none";
}

function planOccursOn(plan, dateKey) {
  const repeat = planRepeat(plan);
  if (repeat === "none") return plan.date === dateKey;
  if (plan.date && dateKey < plan.date) return false;
  if (repeat === "daily") return true;
  return normalizeWeekdays(plan.weekdays).includes(parseDayKey(dateKey).getDay());
}

function planCheckId(planId, dateKey) {
  return `${planId}@${dateKey}`;
}

function isPlanChecked(planId, dateKey) {
  return !!state.planChecks.find((item) => item.id === planCheckId(planId, dateKey))?.done;
}

function togglePlanCheck(planId, dateKey) {
  const plan = state.plans.find((item) => sameId(item.id, planId));
  if (!plan || !planOccursOn(plan, dateKey)) return false;
  const id = planCheckId(planId, dateKey);
  const existing = state.planChecks.find((item) => item.id === id);
  if (existing) {
    existing.done = !existing.done;
    existing.updatedAt = Date.now();
  } else {
    state.planChecks.push({ id, planId, date: dateKey, done: true, updatedAt: Date.now() });
  }
  save();
  render();
  return true;
}

function commuteMin(value) {
  return Math.min(180, Math.max(0, Math.round(Number(value) || 0)));
}

function formatRepeat(plan) {
  const repeat = planRepeat(plan);
  if (repeat === "daily") return "每天";
  if (repeat === "weekly") {
    const names = normalizeWeekdays(plan.weekdays).map((day) => WEEKDAY_LABEL[day]);
    if (!names.length) return "每周";
    if (names.length === 7) return "每天";
    return `每周${names.join("、")}`;
  }
  return "";
}

function assignLanes(blocks) {
  const items = blocks
    .map((block) => {
      const viewStart = Math.max(DAY_START, block.startMin);
      const viewEnd = Math.min(DAY_END, Math.max(viewStart + 5, block.endMin));
      return { ...block, viewStart, viewEnd };
    })
    .filter((block) => block.endMin > DAY_START && block.startMin < DAY_END)
    .sort((a, b) => a.viewStart - b.viewStart || a.viewEnd - b.viewEnd);

  const live = [];
  let cluster = [];
  let clusterEnd = -Infinity;
  const flush = () => {
    const lanes = cluster.reduce((max, item) => Math.max(max, item.lane), 0) + 1;
    cluster.forEach((item) => {
      item.lanes = lanes;
    });
    cluster = [];
  };

  for (const item of items) {
    if (cluster.length && item.viewStart >= clusterEnd) flush();
    const used = new Set(live.filter((other) => other.viewEnd > item.viewStart).map((other) => other.lane));
    let lane = 0;
    while (used.has(lane)) lane += 1;
    item.lane = lane;
    live.push(item);
    cluster.push(item);
    clusterEnd = Math.max(clusterEnd, item.viewEnd);
  }
  if (cluster.length) flush();
  return items;
}

let state = defaultState();
try {
  state = load();
  state.settings = { ...defaultState().settings, ...(state.settings || {}) };
  normalizeSubjects();
  if (!Array.isArray(state.plans)) state.plans = [];
  state.plans = state.plans.map((item) => ({
    ...item,
    repeat: planRepeat(item),
    weekdays: normalizeWeekdays(item.weekdays),
    color: colorOfPlan(item),
    commuteBeforeMin: commuteMin(item.commuteBeforeMin),
    commuteAfterMin: commuteMin(item.commuteAfterMin),
  }));
  if (!state.ui.scheduleDate) state.ui.scheduleDate = dayKey(new Date());
  state.ui.statsDate = dayKey();
  state.ui.statsPeriod = "day";
  state.ui.scheduleDate = dayKey();
  state.ui.tab = "today";
  state.ui.scheduleView = "day";
  if (state.settings.syncDevice !== "phone") state.settings.syncDevice = "tablet";
  if (!state.syncTombs || typeof state.syncTombs !== "object") {
    state.syncTombs = { tasks: [], sessions: [], plans: [], planChecks: [], lists: [], subjects: [] };
  }
  if (state.ui.timerFull && state.timer.run === "idle") state.ui.timerFull = false;
  if (state.ui.demoSeeded !== DEMO_SEED_VER) {
    if (hasUserRecords()) {
      state.ui.demoSeeded = DEMO_SEED_VER;
    } else {
      applyDemoSeed();
      if (!state.ui.selectedListId || state.ui.selectedListId === "inbox") state.ui.selectedListId = "today";
    }
    save();
  }
} catch (error) {
  console.error(error);
  state = sanitizeState(state && typeof state === "object" ? state : defaultState());
}
const TAB_ORDER = ["today", "tasks", "timer", "stats", "settings"];
let ticker = null;
let lastRenderedTab = "";
let activeTransition = null;
let motionClearTimer = 0;
let modalLeaveTimer = 0;
let pendingToggleId = "";
let focusComposer = false;
let committingComposer = false;
let composerOpen = false;
let composerJustOpened = false;
let composerDraft = "";
let bannerTimer = 0;
let lastSnapshot = { boot: true };
const root = document.querySelector("#app");

function prefersReducedMotion() {
  return window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

function snapshotUi() {
  return {
    tab: state.ui.tab,
    timerFull: !!state.ui.timerFull,
    modal: !!state.ui.modal,
    banner: state.ui.banner || "",
    listsOpen: !!state.ui.listsOpen,
    scheduleView: state.ui.scheduleView || "",
    scheduleDate: state.ui.scheduleDate || "",
    statsPeriod: state.ui.statsPeriod || "",
    statsDate: state.ui.statsDate || "",
    selectedListId: state.ui.selectedListId || "",
    theme: document.documentElement.dataset.theme || "",
    boot: false,
  };
}

function inferMotion(prev) {
  if (prev.boot) return "boot";
  if (!!state.ui.timerFull !== prev.timerFull) return "cover";
  if (state.ui.tab !== prev.tab) return "tab";
  if (!!state.ui.listsOpen !== prev.listsOpen) return "drawer";
  if (
    state.ui.tab === "today" &&
    (state.ui.scheduleView !== prev.scheduleView ||
      state.ui.scheduleDate !== prev.scheduleDate)
  ) {
    return "pane";
  }
  if (
    state.ui.tab === "stats" &&
    (state.ui.statsPeriod !== prev.statsPeriod || state.ui.statsDate !== prev.statsDate)
  ) {
    return "pane";
  }
  if (state.ui.tab === "tasks" && state.ui.selectedListId !== prev.selectedListId) return "pane";
  return "";
}

function motionDir(prev, kind) {
  if (kind === "tab") {
    const from = TAB_ORDER.indexOf(prev.tab);
    const to = TAB_ORDER.indexOf(state.ui.tab);
    return from >= 0 && to >= 0 ? Math.sign(to - from) : 0;
  }
  if (kind !== "pane") return 0;
  if (state.ui.tab === "today" && state.ui.scheduleDate !== prev.scheduleDate) {
    return state.ui.scheduleDate > prev.scheduleDate ? 1 : -1;
  }
  if (state.ui.tab === "stats" && state.ui.statsDate !== prev.statsDate) {
    return state.ui.statsDate > prev.statsDate ? 1 : -1;
  }
  return 0;
}

function setMotionMeta(kind, prev) {
  const html = document.documentElement;
  html.dataset.motion = kind;
  const dir = motionDir(prev, kind);
  if (dir) html.dataset.dir = String(dir);
  else delete html.dataset.dir;
}

function clearMotionMeta() {
  const html = document.documentElement;
  delete html.dataset.motion;
  delete html.dataset.dir;
}

function finishMotion(kind) {
  window.clearTimeout(motionClearTimer);
  const hold = kind === "tab" || kind === "boot" || kind === "pane" || kind === "cover" || kind === "drawer" ? 400 : 40;
  motionClearTimer = window.setTimeout(clearMotionMeta, hold);
}

function restartAnim(node, cls) {
  if (!node || !cls) return;
  node.classList.remove("is-enter", "is-enter-left", "is-enter-right");
  void node.offsetWidth;
  node.classList.add(cls);
}

function interruptMotion() {
  window.clearTimeout(motionClearTimer);
  try {
    activeTransition?.skipTransition?.();
  } catch (_) {
    /* View Transition may already have finished. */
  }
  activeTransition = null;
  root.querySelectorAll(".stage-ghost").forEach((node) => node.remove());
  const stage = root.querySelector(".stage");
  stage?.classList.remove("is-enter", "is-enter-left", "is-enter-right");
  root.querySelector(".focus-full")?.classList.remove("is-enter");
  root.querySelector(".pie-chart")?.classList.remove("is-enter");
  clearMotionMeta();
}

function captureStage() {
  const stage = root.querySelector(".shell .stage");
  if (!stage || !stage.innerHTML) return null;
  const scroller = stage.querySelector(".page");
  return { html: stage.innerHTML, scroll: scroller?.scrollTop || 0 };
}

function mountStageGhost(shot, kind, prev) {
  if (!shot?.html || prefersReducedMotion()) return;
  const slot = root.querySelector(".stage-slot");
  if (!slot) return;
  const ghost = document.createElement("div");
  ghost.className = "stage-ghost";
  ghost.setAttribute("aria-hidden", "true");
  ghost.innerHTML = shot.html;
  const scroller = ghost.querySelector(".page");
  if (scroller) scroller.scrollTop = shot.scroll;
  const dir = motionDir(prev, kind);
  ghost.classList.add(
    kind === "pane" && dir === 1 ? "is-leave-left" : kind === "pane" && dir === -1 ? "is-leave-right" : "is-leave",
  );
  slot.appendChild(ghost);
  const kill = () => ghost.remove();
  ghost.addEventListener("animationend", kill, { once: true });
  window.setTimeout(kill, 300);
}

function playPageMotion(kind, prev) {
  if (!kind || prefersReducedMotion()) return;
  if (kind === "cover" && state.ui.timerFull) {
    restartAnim(root.querySelector(".focus-full"), "is-enter");
    return;
  }
  const stage = root.querySelector(".stage");
  if (!stage) return;
  const dir = motionDir(prev, kind);
  const cls =
    kind === "pane" && dir === 1
      ? "is-enter-right"
      : kind === "pane" && dir === -1
        ? "is-enter-left"
        : kind === "tab" || kind === "pane" || kind === "boot" || kind === "cover"
          ? "is-enter"
          : "";
  restartAnim(stage, cls);
  if ((kind === "tab" || kind === "pane") && state.ui.tab === "stats") {
    restartAnim(root.querySelector(".pie-chart"), "is-enter");
  }
}

function afterPaint(prev) {
  const bg = root.querySelector(".modal-bg");
  if (bg) {
    if (prev.modal) bg.classList.add("is-open");
    else {
      const raf = typeof requestAnimationFrame === "function" ? requestAnimationFrame : (fn) => window.setTimeout(fn, 16);
      raf(() => {
        raf(() => bg.classList.add("is-open"));
      });
    }
  }
  if (state.ui.listsOpen && !prev.listsOpen) {
    root.querySelector(".list-pane")?.classList.add("is-opening");
  }
  if (pendingToggleId) {
    const node = root.querySelector(`[data-action="toggle-done"][data-id="${pendingToggleId}"]`);
    pendingToggleId = "";
    if (node) {
      node.classList.add("just-toggled");
      node.addEventListener("animationend", () => node.classList.remove("just-toggled"), { once: true });
    }
  }
  initTimeWheels();
  if (composerJustOpened) {
    composerJustOpened = false;
    restartAnim(root.querySelector(".task-composer"), "is-enter");
  }
  if (focusComposer && state.ui.tab === "tasks") {
    focusComposer = false;
    root.querySelector("#task-composer")?.focus();
  }
}

function pageScroller() {
  return root.querySelector(".stage .page");
}

function resolveColor(id) {
  return PALETTE[id] ? id : "";
}

function hashColor(key) {
  let hash = 0;
  for (const ch of String(key || "amber")) hash = (hash * 31 + ch.charCodeAt(0)) >>> 0;
  return PALETTE_IDS[hash % PALETTE_IDS.length];
}

function nextFreeColor() {
  const used = new Set((state.subjects || []).map((item) => item.color));
  return PALETTE_IDS.find((id) => !used.has(id)) || PALETTE_IDS[(state.subjects || []).length % PALETTE_IDS.length];
}

function colorRgb(id) {
  return (PALETTE[resolveColor(id)] || PALETTE.amber).rgb;
}

function colorOfSubject(id, name) {
  const byId = state.subjects.find((item) => item.id === id);
  if (byId) return resolveColor(byId.color) || hashColor(byId.name);
  const byName = state.subjects.find((item) => item.name === name);
  if (byName) return resolveColor(byName.color) || hashColor(byName.name);
  return hashColor(name || id);
}

function colorOfPlan(plan) {
  return resolveColor(plan?.color) || colorOfSubject(plan?.subjectId, plan?.subjectName);
}

function colorSwatches(name, selected) {
  return `<div class="color-field" role="radiogroup" aria-label="颜色">
    ${PALETTE_IDS.map((id) => {
      const tone = PALETTE[id];
      return `<label class="color-swatch" title="${tone.name}">
        <input type="radio" name="${name}" value="${id}" ${id === selected ? "checked" : ""} />
        <span style="background:rgb(${tone.rgb})"></span>
      </label>`;
    }).join("")}
  </div>`;
}

function normalizeSubjects() {
  const fallback = state.settings.focusMinutes || 25;
  const used = [];
  state.subjects = (state.subjects || []).map((item, index) => {
    const color =
      resolveColor(item.color) ||
      DEFAULT_SUBJECT_COLOR[item.id] ||
      PALETTE_IDS.find((id) => !used.includes(id)) ||
      PALETTE_IDS[index % PALETTE_IDS.length];
    used.push(color);
    return {
      ...item,
      minutes: Number(item.minutes) > 0 ? Number(item.minutes) : fallback,
      color,
    };
  });
}

function demoStamp(dateKey, hour, minute) {
  const date = parseDayKey(dateKey);
  date.setHours(hour, minute, 0, 0);
  return date.getTime();
}

function buildDemoData() {
  const today = dayKey();
  const day = (offset) => shiftDayKey(today, { days: offset });
  const subjects = [
    { id: "en", name: "英语", minutes: 25, color: "lake" },
    { id: "math", name: "数学", minutes: 25, color: "clay" },
    { id: "read", name: "阅读", minutes: 25, color: "pine" },
    { id: "code", name: "编程", minutes: 45, color: "moss" },
    { id: "other", name: "其他", minutes: 25, color: "amber" },
  ];
  const byId = Object.fromEntries(subjects.map((item) => [item.id, item]));
  const lists = [
    { id: "inbox", name: "收集箱", system: "inbox" },
    { id: "today", name: "今天", system: "today" },
    { id: "study", name: "学习" },
    { id: "work", name: "事务" },
    { id: "life", name: "生活" },
  ];
  const task = (id, title, listId, extra = {}) => ({
    id,
    title,
    note: extra.note || "",
    listId,
    isToday: Boolean(extra.isToday),
    estimatedPomos: extra.pomos ?? 1,
    done: Boolean(extra.done),
    createdAt: extra.createdAt || demoStamp(day(extra.ago || 0), 8, 0),
    completedAt: extra.done ? demoStamp(day(extra.ago || 0), 18, 0) : null,
  });
  const tasks = [
    task("demo-t1", "背完 Unit 5 单词", "study", { isToday: true, pomos: 2, note: "重点看词组搭配", ago: 0 }),
    task("demo-t2", "做完函数这一章作业", "study", { isToday: true, pomos: 3, ago: 1 }),
    task("demo-t3", "阅读理解两篇", "study", { isToday: true, pomos: 2, ago: 0 }),
    task("demo-t4", "听力精听一篇", "study", { done: true, pomos: 1, ago: 1 }),
    task("demo-t5", "整理这周错题", "study", { pomos: 2, note: "数学 + 英语", ago: 2 }),
    task("demo-t6", "写一篇周记", "work", { isToday: true, pomos: 1, ago: 0 }),
    task("demo-t7", "回复两条待办消息", "work", { done: true, pomos: 1, ago: 1 }),
    task("demo-t8", "买一本草稿本", "life", { pomos: 0, ago: 3 }),
    task("demo-t9", "晚上跑步 20 分钟", "life", { isToday: true, pomos: 1, ago: 0 }),
    task("demo-t10", "预习下一课语法", "inbox", { pomos: 2, ago: 2 }),
  ];
  const plan = (id, title, date, startMin, endMin, subjectId, extra = {}) => ({
    id,
    title,
    date,
    startMin,
    endMin,
    subjectId,
    subjectName: byId[subjectId]?.name || "",
    color: extra.color || byId[subjectId]?.color || "amber",
    repeat: extra.repeat || "none",
    weekdays: extra.weekdays || [],
  });
  const plans = [
    plan("demo-p1", "背英语单词", day(-14), 7 * 60 + 30, 8 * 60, "en", { repeat: "daily" }),
    plan("demo-p2", "英语听力", today, 9 * 60, 10 * 60 + 30, "en"),
    plan("demo-p3", "单词小测", today, 9 * 60 + 30, 10 * 60, "en", { color: "plum" }),
    plan("demo-p4", "数学作业", day(-21), 19 * 60, 20 * 60 + 30, "math", { repeat: "weekly", weekdays: [1, 3, 5] }),
    plan("demo-p5", "阅读理解", day(-21), 16 * 60, 16 * 60 + 45, "read", { repeat: "weekly", weekdays: [2, 4] }),
    plan("demo-p6", "编程练习", day(-21), 20 * 60, 21 * 60 + 30, "code", { repeat: "weekly", weekdays: [6] }),
    plan("demo-p7", "下午数学", today, 14 * 60, 15 * 60 + 30, "math"),
    plan("demo-p8", "晚间复盘", today, 21 * 60, 21 * 60 + 40, "other"),
    plan("demo-p9", "测验复习", day(1), 10 * 60, 12 * 60, "math"),
    plan("demo-p10", "错题整理", day(4), 9 * 60 + 30, 11 * 60, "other", { color: "sand" }),
  ];
  const session = (id, date, hour, minute, mins, subjectId, taskId = null) => {
    const startedAt = demoStamp(date, hour, minute);
    const durationSec = mins * 60;
    return {
      id,
      taskId,
      subjectId,
      subjectName: byId[subjectId].name,
      mode: "countdown",
      kind: "focus",
      startedAt,
      endedAt: startedAt + durationSec * 1000,
      durationSec,
      completed: true,
    };
  };
  const sessions = [
    session("demo-s01", today, 7, 35, 25, "en", "demo-t1"),
    session("demo-s02", today, 9, 5, 50, "en", "demo-t1"),
    session("demo-s03", today, 14, 10, 30, "math", "demo-t2"),
    session("demo-s04", today, 16, 5, 25, "read", "demo-t3"),
    session("demo-s05", today, 20, 15, 20, "other"),
    session("demo-s06", day(-1), 8, 0, 25, "en"),
    session("demo-s07", day(-1), 15, 10, 25, "math"),
    session("demo-s08", day(-1), 19, 40, 45, "code"),
    session("demo-s09", day(-2), 10, 20, 25, "other"),
    session("demo-s10", day(-2), 16, 0, 25, "read"),
    session("demo-s11", day(-3), 7, 40, 25, "en"),
    session("demo-s12", day(-3), 19, 5, 40, "math"),
    session("demo-s13", day(-4), 9, 15, 25, "en"),
    session("demo-s14", day(-4), 20, 10, 50, "code"),
    session("demo-s15", day(-5), 14, 30, 25, "math"),
    session("demo-s16", day(-6), 8, 10, 25, "en"),
    session("demo-s17", day(-6), 16, 20, 25, "read"),
    session("demo-s18", day(-8), 9, 0, 25, "en"),
    session("demo-s19", day(-8), 19, 20, 30, "math"),
    session("demo-s20", day(-10), 20, 0, 45, "code"),
    session("demo-s21", day(-12), 7, 50, 25, "en"),
    session("demo-s22", day(-15), 15, 40, 25, "read"),
    session("demo-s23", day(-18), 10, 0, 25, "other"),
    session("demo-s24", shiftDayKey(today, { months: -1 }), 9, 10, 25, "en"),
    session("demo-s25", shiftDayKey(today, { months: -1, days: 4 }), 14, 0, 40, "math"),
    session("demo-s26", shiftDayKey(today, { months: -1, days: 11 }), 20, 20, 45, "code"),
    session("demo-s27", shiftDayKey(today, { months: -2 }), 8, 30, 25, "en"),
    session("demo-s28", shiftDayKey(today, { months: -2, days: 8 }), 16, 10, 25, "read"),
    session("demo-s29", "2025-12-18", 9, 0, 30, "en"),
    session("demo-s30", "2025-12-18", 15, 20, 25, "math"),
    session("demo-s31", "2025-11-06", 19, 0, 40, "other"),
  ];
  return { lists, subjects, tasks, plans, sessions };
}

function applyDemoSeed() {
  const demo = buildDemoData();
  state.lists = demo.lists;
  state.subjects = demo.subjects;
  state.tasks = demo.tasks;
  state.plans = demo.plans;
  state.sessions = demo.sessions;
  state.ui.demoSeeded = DEMO_SEED_VER;
  state.ui.scheduleDate = dayKey();
  state.ui.statsDate = dayKey();
  if (state.ui.selectedListId && !state.lists.some((item) => item.id === state.ui.selectedListId)) {
    state.ui.selectedListId = "today";
  }
  if (state.timer.run !== "running") {
    state.timer.subjectId = "en";
    state.timer.subjectName = "英语";
    state.timer.taskId = "demo-t1";
    state.timer.taskTitle = "背完 Unit 5 单词";
  }
  normalizeSubjects();
  state.plans = state.plans.map((item) => ({
    ...item,
    repeat: planRepeat(item),
    weekdays: normalizeWeekdays(item.weekdays),
    color: colorOfPlan(item),
  }));
}

const GIST_DESC = "focuspad-sync";
const GIST_FILE = "focuspad.json";
function save() {
  try {
    stampChangedRecords();
  } catch (_) {}
  localStorage.setItem(
    KEY,
    JSON.stringify({
      ...state,
      ui: { ...state.ui, modal: null, banner: "", statsDate: dayKey(), statsPeriod: "day" },
    }),
  );
  if (!skipCloud) scheduleCloudSync();
}

function saveLocalOnly() {
  skipCloud += 1;
  save();
  skipCloud -= 1;
}

function rememberTomb(kind, id) {
  const sid = String(id || "");
  if (!sid) return;
  if (!state.syncTombs) {
    state.syncTombs = { tasks: [], sessions: [], plans: [], planChecks: [], lists: [], subjects: [] };
  }
  const doomed = (state[kind] || []).find((row) => sameId(row?.id, sid));
  const at = Math.max(Date.now(), itemTime(doomed) + 1);
  const rows = (state.syncTombs[kind] || []).filter((row) => !sameId(tombId(row), sid));
  rows.push({ id: sid, at });
  state.syncTombs[kind] = rows.slice(-500);
}

function localTombAhead(remote) {
  const remoteTombs = remote?.syncTombs || {};
  const localTombs = state.syncTombs || {};
  for (const kind of ["tasks", "sessions", "plans", "planChecks", "lists", "subjects"]) {
    const remoteMap = tombMap(remoteTombs[kind]);
    for (const row of localTombs[kind] || []) {
      const id = tombId(row);
      const at = tombAt(row);
      if (id && at > (remoteMap.get(id) || 0)) return true;
    }
  }
  return false;
}

function captureSessionDraft(form) {
  const modal = state.ui.modal || {};
  const start = form?.querySelector('[name="start"]')?.value || modal.startHm || "09:00";
  const end = form?.querySelector('[name="end"]')?.value || modal.endHm || "09:25";
  return {
    date: String(form?.date?.value || modal.date || dayKey()),
    startHm: formatHm(parseHm(start)),
    endHm: formatHm(parseHm(end)),
    subjectId: String(form?.subjectId?.value || modal.subjectId || ""),
  };
}

function keepSessionForm(draft) {
  state.ui.modal = {
    type: "session-form",
    date: draft.date,
    startHm: draft.startHm,
    endHm: draft.endHm,
    subjectId: draft.subjectId,
    time: { start: draft.startHm, end: draft.endHm },
  };
}

function removeSessionById(id) {
  const sid = String(id || "");
  if (!sid) return false;
  if (!(state.sessions || []).some((item) => sameId(item.id, sid))) return false;
  rememberTomb("sessions", sid);
  state.sessions = state.sessions.filter((item) => !sameId(item.id, sid));
  return true;
}

function isPhoneDevice() {
  return state.settings.syncDevice === "phone";
}

function isNativeApp() {
  return typeof window.FocusPad?.setKeepAwake === "function";
}

function isNativeTablet() {
  return isNativeApp() && !isPhoneDevice();
}

function remoteIsTabletSeed(remote) {
  return !!(remote && remote.tabletSeeded);
}

function remoteUserCount(remote) {
  return remote ? recordUserCount(remote) : 0;
}

function localRecordsMissingFrom(remote) {
  if (!remote) return recordUserCount() > 0;
  for (const key of ["tasks", "sessions", "plans", "planChecks"]) {
    const remoteIds = new Set(
      (remote[key] || []).filter((item) => item?.id).map((item) => String(item.id)),
    );
    for (const item of state[key] || []) {
      if (item?.id && (key === "planChecks" || !isDemoId(item.id)) && !remoteIds.has(String(item.id))) return true;
    }
  }
  return false;
}

function incomingUserCount(remote) {
  if (!remote) return 0;
  let count = 0;
  for (const key of ["tasks", "sessions", "plans", "planChecks"]) {
    const localIds = new Set((state[key] || []).filter((item) => item?.id).map((item) => String(item.id)));
    for (const item of remote[key] || []) {
      if (item?.id && (key === "planChecks" || !isDemoId(item.id)) && !localIds.has(String(item.id))) count += 1;
    }
  }
  return count;
}

function userRecordCountOf(list) {
  return (list || []).filter((item) => item?.id && !isDemoId(item.id)).length;
}

function rememberCloudHint(remote, gistId) {
  if (!remote || typeof remote !== "object") return;
  state.settings.cloudHint = {
    device: remote.device === "phone" ? "phone" : "tablet",
    updatedAt: Number(remote.updatedAt || 0),
    sessions: userRecordCountOf(remote.sessions),
    tasks: userRecordCountOf(remote.tasks),
    plans: userRecordCountOf(remote.plans),
    gistId: String(gistId || state.settings.gistId || ""),
  };
}

function formatSyncWhen(ms) {
  if (!ms) return "";
  return new Date(ms).toLocaleString("zh-CN", {
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function cloudHintHtml() {
  const hint = state.settings.cloudHint;
  const localSessions = userRecordCountOf(state.sessions);
  if (!hint) {
    return `<p class="muted">还没读到云端账本。先确认这台填了和手机同一个令牌，再点立即同步。</p>`;
  }
  const when = formatSyncWhen(hint.updatedAt) || "未知时间";
  const who = hint.device === "phone" ? "手机" : "平板";
  const gap =
    localSessions < hint.sessions
      ? `这台少 ${hint.sessions - localSessions} 条专注，还没接收全。`
      : localSessions > hint.sessions
        ? `这台比云端多 ${localSessions - hint.sessions} 条，下次同步会传上去。`
        : "这台专注条数已经和云端一致。";
  return `<p class="muted">云端最后是${who}在 ${when} 写下的，专注 ${hint.sessions} 条。这台本地专注 ${localSessions} 条。${gap}</p>`;
}

function isDemoId(id) {
  return String(id || "").startsWith("demo-");
}

function recordUserCount(next = state) {
  let count = 0;
  for (const key of ["tasks", "sessions", "plans", "planChecks"]) {
    for (const item of next[key] || []) {
      if (item?.id && (key === "planChecks" || !isDemoId(item.id))) count += 1;
    }
  }
  return count;
}

function looksLikeDemoOnly(next = state) {
  return recordUserCount(next) === 0 && ["tasks", "sessions", "plans"].some((key) =>
    (next[key] || []).some((item) => isDemoId(item?.id)),
  );
}

function cloudToken() {
  return String(state.settings.githubToken || "").trim();
}

function scheduleCloudSync() {
  if (!cloudToken() || !isNativeApp()) return;
  cloudDirty = true;
  if (cloudBusy) return;
  window.clearTimeout(cloudTimer);
  cloudTimer = window.setTimeout(flushCloudSync, 1200);
}

function flushCloudSync() {
  if (!cloudDirty || cloudBusy || !cloudToken() || !isNativeApp()) return;
  cloudSync({ silent: true });
}

function cloudHeaders(token) {
  return {
    Accept: "application/vnd.github+json",
    Authorization: `Bearer ${token}`,
    "X-GitHub-Api-Version": "2022-11-28",
  };
}

function cloudExport() {
  const settings = state.settings || {};
  return {
    v: 1,
    updatedAt: Date.now(),
    device: isPhoneDevice() ? "phone" : "tablet",
    lists: state.lists,
    subjects: state.subjects,
    tasks: state.tasks,
    sessions: state.sessions,
    plans: state.plans,
    planChecks: state.planChecks,
    syncTombs: state.syncTombs,
    settings: {
      focusMinutes: settings.focusMinutes,
      shortBreakMinutes: settings.shortBreakMinutes,
      longBreakMinutes: settings.longBreakMinutes,
      cyclesBeforeLongBreak: settings.cyclesBeforeLongBreak,
      dailyGoal: settings.dailyGoal,
      themeMode: settings.themeMode,
    },
    demoSeeded: state.ui.demoSeeded || "",
    nativeTablet: isNativeTablet() || cloudTabletSeeded,
    tabletSeeded: isNativeTablet() || cloudTabletSeeded,
    tabletSeedRev: cloudTabletSeedRev,
  };
}

function mergeRecords(localList, remoteList, localTombs, remoteTombs) {
  const localItems = new Map((localList || []).filter((item) => item?.id).map((item) => [String(item.id), item]));
  const remoteItems = new Map((remoteList || []).filter((item) => item?.id).map((item) => [String(item.id), item]));
  const tombs = tombMap(localTombs);
  for (const [id, at] of tombMap(remoteTombs)) {
    tombs.set(id, Math.max(tombs.get(id) || 0, at));
  }
  const items = [];
  const outTombs = [];
  const ids = new Set([...localItems.keys(), ...remoteItems.keys(), ...tombs.keys()]);
  for (const id of ids) {
    const local = localItems.get(id);
    const remote = remoteItems.get(id);
    const picked = !local ? remote : !remote ? local : itemTime(local) >= itemTime(remote) ? local : remote;
    const deletedAt = tombs.get(id);
    if (picked && (deletedAt == null || itemTime(picked) > deletedAt)) {
      items.push(picked);
      continue;
    }
    if (deletedAt != null) outTombs.push({ id, at: deletedAt });
  }
  return { items, tombs: outTombs };
}

function applyTabletSnapshot(remote) {
  if (!remote || typeof remote !== "object") return false;
  state.lists = Array.isArray(remote.lists) ? remote.lists : state.lists;
  state.subjects = remote.subjects?.length ? remote.subjects : state.subjects;
  state.tasks = Array.isArray(remote.tasks) ? remote.tasks : state.tasks;
  state.sessions = Array.isArray(remote.sessions) ? remote.sessions : state.sessions;
  state.plans = Array.isArray(remote.plans) ? remote.plans : state.plans;
  state.planChecks = Array.isArray(remote.planChecks) ? remote.planChecks : state.planChecks;
  if (remote.syncTombs && typeof remote.syncTombs === "object") state.syncTombs = remote.syncTombs;
  if (remote.demoSeeded) state.ui.demoSeeded = remote.demoSeeded;
  normalizeSubjects();
  rememberRecordCores();
  return true;
}

function applyCloudPayload(remote) {
  if (!remote || typeof remote !== "object") return false;
  const localTombs = state.syncTombs || {};
  const remoteTombs = remote.syncTombs || {};
  const lists = mergeRecords(state.lists, remote.lists, localTombs.lists, remoteTombs.lists);
  const subjects = mergeRecords(state.subjects, remote.subjects, localTombs.subjects, remoteTombs.subjects);
  const tasks = mergeRecords(state.tasks, remote.tasks, localTombs.tasks, remoteTombs.tasks);
  const sessions = mergeRecords(state.sessions, remote.sessions, localTombs.sessions, remoteTombs.sessions);
  const plans = mergeRecords(state.plans, remote.plans, localTombs.plans, remoteTombs.plans);
  const planChecks = mergeRecords(state.planChecks, remote.planChecks, localTombs.planChecks, remoteTombs.planChecks);
  const keep = {
    githubToken: state.settings.githubToken,
    gistId: state.settings.gistId,
    syncDevice: state.settings.syncDevice,
    updateUrl: state.settings.updateUrl,
    autoUpdate: state.settings.autoUpdate,
    lastSyncAt: state.settings.lastSyncAt,
  };
  const picked = state.settings;
  const before = JSON.stringify(cloudExport());
  state.lists = lists.items;
  state.subjects = subjects.items.length ? subjects.items : state.subjects;
  state.tasks = tasks.items;
  state.sessions = sessions.items;
  state.plans = plans.items;
  state.planChecks = planChecks.items;
  state.syncTombs = {
    lists: lists.tombs,
    subjects: subjects.tombs,
    tasks: tasks.tombs,
    sessions: sessions.tombs,
    plans: plans.tombs,
    planChecks: planChecks.tombs,
  };
  state.settings = { ...picked, ...keep };
  if (remote.demoSeeded) state.ui.demoSeeded = remote.demoSeeded;
  normalizeSubjects();
  rememberRecordCores();
  const after = JSON.stringify(cloudExport());
  return before !== after;
}

async function githubJson(url, token, options = {}) {
  const res = await fetch(url, {
    ...options,
    headers: { ...cloudHeaders(token), ...(options.headers || {}) },
  });
  const text = await res.text();
  let data = null;
  try {
    data = text ? JSON.parse(text) : null;
  } catch {
    data = null;
  }
  if (!res.ok) {
    const err = new Error(data?.message || `HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  return data;
}

async function findCloudGist(token) {
  const saved = String(state.settings.gistId || "").trim();
  if (saved) {
    try {
      const gist = await githubJson(`https://api.github.com/gists/${saved}`, token);
      if (gist?.files?.[GIST_FILE]) return saved;
    } catch (error) {
      if (error.status && error.status !== 404) throw error;
    }
  }
  const rows = await githubJson("https://api.github.com/gists?per_page=100", token);
  const found = (Array.isArray(rows) ? rows : []).find(
    (item) => item.description === GIST_DESC && item.files && item.files[GIST_FILE],
  );
  if (found?.id) {
    state.settings.gistId = found.id;
    saveLocalOnly();
    return found.id;
  }
  return "";
}

async function readCloudGist(token, id) {
  const gist = await githubJson(`https://api.github.com/gists/${id}`, token);
  const file = gist?.files?.[GIST_FILE];
  if (!file) return null;
  let raw = file.content || "";
  if (file.truncated && file.raw_url) {
    const res = await fetch(file.raw_url, { headers: cloudHeaders(token) });
    raw = await res.text();
  }
  if (!raw) return null;
  try {
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

async function writeCloudGist(token, id, payload) {
  const body = {
    description: GIST_DESC,
    public: false,
    files: { [GIST_FILE]: { content: JSON.stringify(payload) } },
  };
  if (id) {
    await githubJson(`https://api.github.com/gists/${id}`, token, {
      method: "PATCH",
      body: JSON.stringify(body),
    });
    return id;
  }
  const created = await githubJson("https://api.github.com/gists", token, {
    method: "POST",
    body: JSON.stringify(body),
  });
  return created?.id || "";
}

async function cloudSync(options = {}) {
  const silent = !!options.silent;
  const token = cloudToken();
  if (!token || cloudBusy) return false;
  cloudBusy = true;
  cloudDirty = false;
  if (state.ui.tab === "settings") render();
  try {
    let id = await findCloudGist(token);
    const remote = id ? await readCloudGist(token, id) : null;
    if (remote) rememberCloudHint(remote, id);
    const nativeSeed = remoteIsTabletSeed(remote);
    const seenRev = Number(state.settings.tabletSeedRev || 0);
    const remoteRev = Number(remote?.tabletSeedRev || 0);
    const remoteUsers = remoteUserCount(remote);
    const incoming = incomingUserCount(remote);
    const forceTabletSeed =
      !!options.forceTabletSeed || (isNativeTablet() && !nativeSeed && remoteUsers === 0);
    const demoPhone = isPhoneDevice() && looksLikeDemoOnly();
    const phoneAdopt =
      !!options.forcePhonePull ||
      (isPhoneDevice() &&
        !!remote &&
        !localTombAhead(remote) &&
        !localRecordsMissingFrom(remote) &&
        (((nativeSeed && remoteRev > seenRev) || (demoPhone && (nativeSeed || remoteUsers > 0)))));
    const tabletAdopt =
      isNativeTablet() &&
      !options.forceTabletSeed &&
      looksLikeDemoOnly() &&
      remoteUsers > 0 &&
      !localTombAhead(remote);

    if (!isNativeApp()) {
      const changed = remoteUsers > 0 ? applyCloudPayload(remote) : nativeSeed ? applyTabletSnapshot(remote) : false;
      state.ui.syncStatus =
        remoteUsers > 0 || nativeSeed ? "电脑只预览云端，不会改平板数据" : "等平板或手机 App 先同步，电脑不会写云端";
      saveLocalOnly();
      if (changed || state.ui.tab === "settings") render();
      if (!silent) banner(state.ui.syncStatus);
      return true;
    }

    let changed = false;
    if (forceTabletSeed) {
      cloudTabletSeeded = true;
      cloudTabletSeedRev = remoteRev + 1;
    } else if (phoneAdopt || tabletAdopt) {
      changed = applyTabletSnapshot(remote);
      cloudTabletSeeded = true;
      cloudTabletSeedRev = Math.max(remoteRev, 1);
      state.settings.tabletSeedRev = cloudTabletSeedRev;
    } else {
      cloudTabletSeeded = true;
      cloudTabletSeedRev = Math.max(remoteRev, seenRev, nativeSeed ? remoteRev : 1);
      changed = remote ? applyCloudPayload(remote) : false;
    }

    const payload = cloudExport();
    id = await writeCloudGist(token, id, payload);
    if (id && id !== state.settings.gistId) state.settings.gistId = id;
    rememberCloudHint(payload, id);
    if (isNativeTablet()) state.settings.tabletSeedRev = payload.tabletSeedRev;
    state.settings.lastSyncAt = Date.now();
    state.ui.syncStatus = forceTabletSeed
      ? "已用平板数据写入云端"
      : phoneAdopt
        ? "已从平板底稿更新"
        : tabletAdopt || incoming > 0
          ? incoming > 0
            ? `已同步云端 ${incoming} 条记录`
            : "已从云端更新"
          : silent
            ? "已自动同步"
            : "已同步";
    saveLocalOnly();
    if (changed || incoming > 0 || state.ui.tab === "settings") render();
    if (!silent || incoming > 0 || tabletAdopt) banner(state.ui.syncStatus);
    return true;
  } catch (error) {
    const status = error.status;
    const message =
      status === 401 || status === 403
        ? "令牌无效或没有 gist 权限"
        : /Failed to fetch|NetworkError|offline/i.test(String(error.message || ""))
          ? "网络不好，稍后再同步"
          : "同步失败";
    state.ui.syncStatus = message;
    if (state.ui.tab === "settings") render();
    cloudDirty = true;
    if (!silent || isNativeApp()) banner(message);
    return false;
  } finally {
    cloudBusy = false;
    if (state.ui.tab === "settings") render();
    if (cloudDirty) {
      window.clearTimeout(cloudTimer);
      cloudTimer = window.setTimeout(flushCloudSync, silent ? 8000 : 1200);
    }
  }
}

function set(patch) {
  state = { ...state, ...patch };
  save();
  render();
}

function patchUi(partial) {
  state.ui = { ...state.ui, ...partial };
  render();
}

function patchSettings(partial) {
  state.settings = { ...state.settings, ...partial };
  const kindMap = {
    focusMinutes: "focus",
    shortBreakMinutes: "shortBreak",
    longBreakMinutes: "longBreak",
  };
  if (partial.focusMinutes != null) {
    const subject = state.subjects.find((item) => item.id === state.timer.subjectId);
    if (subject) subject.minutes = partial.focusMinutes;
  }
  for (const [key, kind] of Object.entries(kindMap)) {
    if (partial[key] != null && state.timer.run !== "running" && state.timer.kind === kind && state.timer.mode === "countdown") {
      applyTargetSeconds(partial[key] * 60);
    }
  }
  save();
  applyTheme();
  render();
}

function applyTheme() {
  const mode = state.settings.themeMode;
  let theme = mode;
  if (mode === "system") {
    theme = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
  }
  document.documentElement.dataset.theme = theme;
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", theme === "dark" ? "#171d19" : "#f5f3ec");
}

function kindSeconds(kind) {
  const s = state.settings;
  if (kind === "shortBreak") return s.shortBreakMinutes * 60;
  if (kind === "longBreak") return s.longBreakMinutes * 60;
  const subject = state.subjects.find((item) => item.id === state.timer.subjectId);
  return (subject?.minutes || s.focusMinutes) * 60;
}

function currentMinutes() {
  return Math.max(1, Math.round(kindSeconds(state.timer.kind) / 60));
}

function applyTargetSeconds(nextTarget) {
  const t = state.timer;
  if (t.mode !== "countdown") return;
  const now = Date.now();
  const used =
    t.run === "running"
      ? t.targetSec - remaining(now)
      : t.run === "paused"
        ? t.elapsedSec
        : 0;
  t.targetSec = Math.max(60, nextTarget);
  if (t.run === "running") {
    const left = Math.max(0, t.targetSec - Math.max(0, used));
    t.elapsedSec = t.targetSec - left;
    t.endAt = now + left * 1000;
    if (left <= 0) finishCountdown();
  } else if (t.run === "paused") {
    t.elapsedSec = Math.min(Math.max(0, used), t.targetSec);
  } else {
    t.elapsedSec = 0;
    t.endAt = null;
  }
}

function applyDurationMinutes(minutes) {
  if (state.timer.run === "running") return;
  const next = Math.min(180, Math.max(1, minutes));
  if (state.timer.kind === "shortBreak") {
    state.settings.shortBreakMinutes = next;
  } else if (state.timer.kind === "longBreak") {
    state.settings.longBreakMinutes = next;
  } else {
    state.settings.focusMinutes = next;
    const subject = state.subjects.find((item) => item.id === state.timer.subjectId);
    if (subject) subject.minutes = next;
  }
  applyTargetSeconds(next * 60);
  save();
  render();
}

function remaining(now = Date.now()) {
  const t = state.timer;
  if (t.mode === "countup") return 0;
  if (t.run === "running" && t.endAt) return Math.max(0, Math.round((t.endAt - now) / 1000));
  return Math.max(0, t.targetSec - t.elapsedSec);
}

function displayed(now = Date.now()) {
  const t = state.timer;
  if (t.mode === "countup") {
    if (t.run === "running" && (t.resumeAt || t.startedAt)) {
      return t.elapsedSec + Math.max(0, Math.round((now - (t.resumeAt || t.startedAt)) / 1000));
    }
    return t.elapsedSec;
  }
  return remaining(now);
}

function formatClock(sec) {
  const n = Math.max(0, sec);
  const h = Math.floor(n / 3600);
  const m = Math.floor((n % 3600) / 60);
  const s = n % 60;
  const pad = (v) => String(v).padStart(2, "0");
  return h > 0 ? `${pad(h)}:${pad(m)}:${pad(s)}` : `${pad(m)}:${pad(s)}`;
}

function formatFocus(sec) {
  if (sec <= 0) return "0 分钟";
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  if (h && m) return `${h} 小时 ${m} 分`;
  if (h) return `${h} 小时`;
  return `${m} 分钟`;
}

function kindLabel(kind) {
  if (kind === "shortBreak") return "短休息";
  if (kind === "longBreak") return "长休息";
  return "专注";
}

function selectedList() {
  const lists = Array.isArray(state.lists) ? state.lists : [];
  return lists.find((l) => l.id === state.ui.selectedListId) || lists[0] || { id: "today", name: "今天", system: "today" };
}

function visibleTasks() {
  const list = selectedList();
  const tasks = Array.isArray(state.tasks) ? state.tasks : [];
  const visible = list.system === "today" ? tasks.filter((t) => t.isToday) : tasks.filter((t) => t.listId === list.id);
  return visible.sort((a, b) => Number(a.done) - Number(b.done) || Number(b.createdAt || 0) - Number(a.createdAt || 0));
}

function rangeFor(period, dateKey = state.ui.statsDate || dayKey()) {
  const cursor = parseDayKey(dateKey);
  if (period === "day") {
    const start = new Date(cursor.getFullYear(), cursor.getMonth(), cursor.getDate());
    const end = new Date(start);
    end.setDate(start.getDate() + 1);
    return [start.getTime(), end.getTime()];
  }
  if (period === "week") {
    const start = parseDayKey(startOfWeek(dateKey));
    const end = new Date(start);
    end.setDate(start.getDate() + 7);
    return [start.getTime(), end.getTime()];
  }
  if (period === "month") {
    const start = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    return [start.getTime(), new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1).getTime()];
  }
  if (period === "year") {
    const start = new Date(cursor.getFullYear(), 0, 1);
    return [start.getTime(), new Date(cursor.getFullYear() + 1, 0, 1).getTime()];
  }
  return [0, Number.MAX_SAFE_INTEGER];
}

function statsBundle() {
  const [from, to] = rangeFor(state.ui.statsPeriod);
  const rows = state.sessions.filter(
    (s) => s.kind === "focus" && s.completed && s.startedAt >= from && s.startedAt < to,
  );
  const bySubject = {};
  const bySlot = { "凌晨 0-6": 0, "上午 6-12": 0, "下午 12-18": 0, "晚上 18-24": 0 };
  const byYear = {};
  let focusSeconds = 0;
  for (const row of rows) {
    focusSeconds += row.durationSec;
    bySubject[row.subjectName] = (bySubject[row.subjectName] || 0) + row.durationSec;
    const started = new Date(row.startedAt);
    const hour = started.getHours();
    const slot = hour < 6 ? "凌晨 0-6" : hour < 12 ? "上午 6-12" : hour < 18 ? "下午 12-18" : "晚上 18-24";
    bySlot[slot] += row.durationSec;
    const year = String(started.getFullYear());
    byYear[year] = (byYear[year] || 0) + row.durationSec;
  }
  return {
    focusSeconds,
    focusCount: rows.length,
    bySubject: Object.entries(bySubject).sort((a, b) => b[1] - a[1]),
    bySlot: Object.entries(bySlot),
    byYear: Object.entries(byYear).sort((a, b) => Number(b[0]) - Number(a[0])),
  };
}

function bannerNode() {
  return root.querySelector(":scope > .banner");
}

function paintBanner() {
  const text = state.ui.banner;
  const node = bannerNode();
  if (!text) {
    if (node && node.parentNode) node.parentNode.removeChild(node);
    return;
  }
  if (node && node.textContent === text && !node.classList.contains("is-leaving")) return;
  node?.remove();
  const next = document.createElement("div");
  next.className = "banner";
  next.textContent = text;
  root.appendChild(next);
}

function dismissBanner() {
  window.clearTimeout(bannerTimer);
  bannerTimer = 0;
  state.ui.banner = "";
  const node = bannerNode();
  if (!node) return;
  if (prefersReducedMotion()) {
    node.remove();
    return;
  }
  node.classList.add("is-leaving");
  window.setTimeout(() => {
    if (node.classList.contains("is-leaving")) node.remove();
  }, 280);
}

function banner(text) {
  window.clearTimeout(bannerTimer);
  const next = String(text || "").trim();
  if (!next) {
    dismissBanner();
    return;
  }
  state.ui.banner = next;
  paintBanner();
  bannerTimer = window.setTimeout(dismissBanner, 3000);
}

function notify(title, body) {
  if (window.Notification && Notification.permission === "granted") {
    new Notification(title, { body });
  }
  if (navigator.vibrate) navigator.vibrate([80, 40, 80]);
  banner(`${title}：${body}`);
}

function setImmersive(on) {
  try {
    if (window.FocusPad?.setImmersive) {
      window.FocusPad.setImmersive(on);
      return;
    }
  } catch (_) {}
  if (isNativeApp()) return;
  const node = document.documentElement;
  if (on && node.requestFullscreen) {
    node.requestFullscreen().catch(() => {});
  } else if (!on && document.fullscreenElement && document.exitFullscreen) {
    document.exitFullscreen().catch(() => {});
  }
}

function enterFocusFull() {
  state.ui.tab = "timer";
  state.ui.timerFull = true;
  setImmersive(true);
}

function leaveFocusFull() {
  state.ui.timerFull = false;
  setImmersive(false);
}

function startTicker() {
  stopTicker();
  ticker = window.setInterval(() => {
    const t = state.timer;
    if (t.run !== "running") return;
    if (t.mode === "countdown" && remaining() <= 0) {
      finishCountdown();
      return;
    }
    renderTimerOnly();
  }, 200);
}

function stopTicker() {
  if (ticker) window.clearInterval(ticker);
  ticker = null;
}

function startTimer() {
  const t = state.timer;
  if (t.run === "running") return;
  const now = Date.now();
  if (!t.subjectId && state.subjects[0]) {
    t.subjectId = state.subjects[0].id;
    t.subjectName = state.subjects[0].name;
  }
  if (t.mode === "countup") {
    t.run = "running";
    t.startedAt = t.startedAt || now;
    t.resumeAt = now;
    t.endAt = null;
  } else {
    const left = remaining(now) || t.targetSec;
    t.run = "running";
    t.startedAt = t.startedAt || now;
    t.endAt = now + left * 1000;
  }
  if (t.kind === "focus") {
    enterFocusFull();
  }
  save();
  startTicker();
  render();
  syncKeepAwake();
  if (window.Notification && Notification.permission === "default") {
    Notification.requestPermission();
  }
}

function pauseTimer() {
  const t = state.timer;
  const now = Date.now();
  if (t.mode === "countup") {
    t.elapsedSec = displayed(now);
    t.resumeAt = null;
  } else {
    t.elapsedSec = t.targetSec - remaining(now);
    t.endAt = null;
  }
  t.run = "paused";
  stopTicker();
  save();
  render();
  syncKeepAwake();
}

function resetTimer() {
  const t = state.timer;
  state.timer = idleTimer(
    t.mode,
    t.mode === "countup" ? "focus" : t.kind,
    kindSeconds(t.mode === "countup" ? "focus" : t.kind),
    t.subjectId,
    t.subjectName,
  );
  state.timer.taskId = t.taskId;
  state.timer.taskTitle = t.taskTitle;
  state.timer.completedFocus = t.completedFocus;
  stopTicker();
  leaveFocusFull();
  save();
  render();
  syncKeepAwake();
}

function recordIfNeeded(durationSec, startedAt, kind, mode) {
  if (kind !== "focus" || durationSec < 30 || !state.timer.subjectId) return;
  state.sessions.push({
    id: uid(),
    taskId: state.timer.taskId,
    subjectId: state.timer.subjectId,
    subjectName: state.timer.subjectName,
    mode,
    kind,
    startedAt,
    endedAt: Date.now(),
    durationSec,
    completed: true,
  });
}

function sessionDayKey(item) {
  const at = Number(item?.startedAt);
  if (!Number.isFinite(at)) return "";
  return dayKey(new Date(at));
}

function sessionsOnDate(dateStr) {
  return (state.sessions || [])
    .filter((item) => item.kind === "focus" && item.completed && sessionDayKey(item) === dateStr)
    .sort((a, b) => a.startedAt - b.startedAt);
}

function openSessionForm(dateOverride = "") {
  const now = new Date();
  const viewingDay = dateOverride || (state.ui.tab === "stats" && state.ui.statsPeriod === "day" && state.ui.statsDate);
  const date = viewingDay || dayKey(now);
  const minutes = Math.max(1, currentMinutes() || state.settings.focusMinutes || 25);
  let start = new Date(now.getTime() - minutes * 60 * 1000);
  if (date !== dayKey(now)) {
    const cursor = parseDayKey(date);
    cursor.setHours(9, 0, 0, 0);
    start = cursor;
  } else if (dayKey(start) !== date) {
    start = new Date(now);
    start.setMinutes(Math.max(0, start.getMinutes() - minutes), 0, 0);
  }
  const startMin = minutesOf(start);
  state.ui.modal = {
    type: "session-form",
    date,
    startHm: formatHm(startMin),
    endHm: formatHm(Math.min(24 * 60 - 1, startMin + minutes)),
    subjectId: state.timer.subjectId || state.subjects[0]?.id || "",
  };
  render();
}

function addManualSession(subject, startedAt, durationSec) {
  state.sessions.push({
    id: uid(),
    taskId: null,
    subjectId: subject.id,
    subjectName: subject.name,
    mode: "manual",
    kind: "focus",
    startedAt,
    endedAt: startedAt + durationSec * 1000,
    durationSec,
    completed: true,
    manual: true,
    createdAt: Date.now(),
    updatedAt: Date.now(),
  });
}

function advanceAfterFocus() {
  const t = state.timer;
  let count = t.completedFocus;
  let nextKind = "focus";
  if (t.kind === "focus") {
    count += 1;
    if (t.mode === "countdown") {
      nextKind = count % state.settings.cyclesBeforeLongBreak === 0 ? "longBreak" : "shortBreak";
    }
  }
  state.timer = idleTimer(
    t.mode,
    t.mode === "countup" ? "focus" : nextKind,
    kindSeconds(t.mode === "countup" ? "focus" : nextKind),
    t.subjectId,
    t.subjectName,
  );
  state.timer.taskId = t.taskId;
  state.timer.taskTitle = t.taskTitle;
  state.timer.completedFocus = count;
}

function finishCountdown() {
  const t = state.timer;
  const startedAt = t.startedAt || Date.now() - t.targetSec * 1000;
  recordIfNeeded(t.targetSec, startedAt, t.kind, t.mode);
  notify("时间到", t.kind === "focus" ? "专注结束，起来活动一下" : "休息结束，可以继续了");
  advanceAfterFocus();
  stopTicker();
  leaveFocusFull();
  save();
  render();
  syncKeepAwake();
}

function finishCountup() {
  const t = state.timer;
  const duration = displayed();
  const startedAt = t.startedAt ? t.startedAt : Date.now() - duration * 1000;
  recordIfNeeded(duration, startedAt, "focus", "countup");
  notify("已记录", `本次专注 ${formatFocus(duration)}`);
  advanceAfterFocus();
  stopTicker();
  leaveFocusFull();
  save();
  render();
  syncKeepAwake();
}

function esc(text) {
  return String(text)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function navItem(id, icon, label) {
  const current = state.ui.tab === id;
  return `<button data-action="nav" data-tab="${id}"${current ? ' aria-current="page"' : ""}>
    <span class="nav-ico"><span class="icon icon-${icon}" aria-hidden="true"></span></span>
    <span class="nav-label">${label}</span>
  </button>`;
}

function navButtonsHtml() {
  return `${navItem("today", "schedule", "今天")}
      ${navItem("tasks", "list", "任务")}
      ${navItem("timer", "timer", "专注")}
      ${navItem("stats", "stats", "统计")}
      ${navItem("settings", "settings", "设置")}`;
}

function syncNav(nav) {
  if (!nav) return;
  nav.querySelectorAll("[data-action=nav]").forEach((btn) => {
    if (btn.dataset.tab === state.ui.tab) btn.setAttribute("aria-current", "page");
    else btn.removeAttribute("aria-current");
  });
}

function overlayHtml() {
  return renderModal();
}

function paintOverlays() {
  let overlays = root.querySelector(":scope > .overlays");
  if (!overlays) {
    overlays = document.createElement("div");
    overlays.className = "overlays";
    root.appendChild(overlays);
  }
  overlays.innerHTML = overlayHtml();
}

function pageHtml() {
  if (state.ui.tab === "timer") return renderTimer();
  if (state.ui.tab === "today") return renderToday();
  if (state.ui.tab === "stats") return renderStats();
  if (state.ui.tab === "settings") return renderSettings();
  return renderTasks();
}

function openComposer() {
  if (composerOpen) {
    focusComposer = true;
    root.querySelector("#task-composer")?.focus();
    return;
  }
  composerOpen = true;
  composerJustOpened = true;
  focusComposer = true;
  render();
}

function closeComposer() {
  composerOpen = false;
  composerJustOpened = false;
  composerDraft = "";
  focusComposer = false;
}

function flushComposer() {
  if (!composerOpen) {
    closeComposer();
    return;
  }
  const input = root.querySelector("#task-composer");
  if (String(input?.value || composerDraft || "").trim()) {
    commitComposer(input || { value: composerDraft }, false);
  }
  closeComposer();
}

function goTab(tab) {
  if (!tab || !TAB_ORDER.includes(tab)) return;
  if (state.ui.tab === tab && !state.ui.timerFull) return;
  flushComposer();
  state.ui.tab = tab;
  state.ui.listsOpen = false;
  render();
  if (tab === "settings") probeRemoteVersion();
}

function probeRemoteVersion() {
  const base = resolvedUpdateUrl().replace(/\/?$/, "/");
  fetch(`${base}update.json?t=${Date.now()}`, { cache: "no-store" })
    .then((res) => res.json())
    .then((manifest) => {
      const version = Number(manifest.version) || 0;
      if (!version || state.ui.remoteVersion === version) return;
      state.ui.remoteVersion = version;
      if (state.ui.tab === "settings") render();
    })
    .catch(() => {});
}

function renderTasks() {
  const list = selectedList();
  const listTitle = list.system === "today" ? "今日任务" : list.name;
  const tasks = visibleTasks();
  const openCount = tasks.filter((item) => !item.done).length;
  const lists = state.lists
    .map((item) => {
      const current = item.id === list.id;
      const extra = item.system
        ? ""
        : `<button class="list-more" data-action="list-menu" data-id="${item.id}" aria-label="清单操作"><span class="icon icon-more" aria-hidden="true"></span></button>`;
      const mark =
        item.system === "inbox"
          ? `<span class="icon icon-inbox list-mark" aria-hidden="true"></span>`
          : item.system === "today"
            ? `<span class="icon icon-today list-mark" aria-hidden="true"></span>`
            : `<span class="list-mark list-mark-plain" aria-hidden="true"></span>`;
      return `<div class="list-item" aria-current="${current}">
        <button data-action="select-list" data-id="${item.id}">
          ${mark}
          <span>${esc(item.system === "today" ? "今日任务" : item.name)}</span>
        </button>
        ${extra}
      </div>`;
    })
    .join("");

  const cards = tasks.map((task) => taskCardHtml(task, list)).join("");

  return `<div class="wide">
    <aside class="list-pane ${state.ui.listsOpen ? "open" : ""}">
      <div class="page-head"><h1>清单</h1></div>
      ${lists}
      <button class="btn" data-action="add-list" style="width:100%;margin-top:8px">新建清单</button>
    </aside>
    <button type="button" class="list-scrim" data-action="toggle-lists" aria-label="关闭清单" tabindex="-1"></button>
    <section class="task-pane page">
      <div class="page-head">
        <div class="row">
          <button class="btn menu-btn" data-action="toggle-lists">清单</button>
          <div class="task-heading"><h1>${esc(listTitle)}</h1><span>${openCount} 项待完成${tasks.length > openCount ? ` · ${tasks.length - openCount} 项已完成` : ""}</span></div>
        </div>
      </div>
      <div class="task-list">
        ${cards || (composerOpen || composerDraft ? "" : `<p class="empty">这个清单还没有任务</p>`)}
        ${
          composerOpen || composerDraft
            ? `<form class="task-card task-composer" data-form="task-quick" autocomplete="off">
          <span class="check composer-mark" aria-hidden="true"></span>
          <input id="task-composer" class="task-composer-input" name="title" maxlength="4000" enterkeyhint="done" value="${esc(composerDraft)}" aria-label="新建任务" />
        </form>`
            : ""
        }
        <button type="button" class="task-add-plus" data-action="open-composer" aria-label="新建任务">
          <span class="task-add-plus-mark">
            <span class="icon icon-plus" aria-hidden="true"></span>
          </span>
        </button>
      </div>
    </section>
  </div>`;
}

function timerRingHtml(shown, progress) {
  const dash = CIRC * Math.max(0, Math.min(1, progress));
  const t = state.timer;
  return `<div class="ring-box" id="ring-box">
    <svg viewBox="0 0 200 200" aria-hidden="true">
      <circle class="ring-track" cx="100" cy="100" r="86"></circle>
      ${
        progress >= 0.02
          ? `<circle class="ring-value" cx="100" cy="100" r="86" stroke-dasharray="${dash} ${CIRC}"></circle>`
          : ""
      }
    </svg>
    <div class="ring-copy">
      <div>
        <div class="muted">${t.mode === "countup" ? "正计时" : kindLabel(t.kind)}</div>
        <div class="clock" id="clock">${formatClock(shown)}</div>
        <div class="muted">${esc(t.taskTitle || t.subjectName || "未选择科目")}</div>
      </div>
    </div>
  </div>`;
}

function renderFocusFull() {
  const t = state.timer;
  const now = Date.now();
  const shown = displayed(now);
  const progress =
    t.mode === "countup"
      ? Math.min(1, shown / 3600)
      : t.targetSec
        ? 1 - shown / t.targetSec
        : 0;
  const running = t.run === "running";
  return `<section class="focus-full">
    <button class="btn ghost focus-exit" data-action="exit-full">退出全屏</button>
    ${timerRingHtml(shown, progress)}
    <div class="actions">
      ${
        running
          ? `<button class="btn primary" data-action="pause"><span class="icon icon-pause" aria-hidden="true"></span>暂停</button>`
          : `<button class="btn primary" data-action="start"><span class="icon icon-play" aria-hidden="true"></span>${t.run === "paused" ? "继续" : "开始"}</button>`
      }
      ${
        t.mode === "countup" && t.run !== "idle"
          ? `<button class="btn" data-action="finish-up">结束并记录</button>`
          : ""
      }
      <button class="btn" data-action="reset">重置</button>
    </div>
  </section>`;
}

function renderTimer() {
  const t = state.timer;
  const now = Date.now();
  const shown = displayed(now);
  const progress =
    t.mode === "countup"
      ? Math.min(1, shown / 3600)
      : t.targetSec
        ? 1 - shown / t.targetSec
        : 0;
  const running = t.run === "running";
  const chips = state.subjects
    .map(
      (s) =>
        `<button class="chip" data-action="subject" data-id="${s.id}" aria-pressed="${t.subjectId === s.id}" style="--tone:${colorRgb(s.color)}"><i class="chip-dot" aria-hidden="true"></i>${esc(s.name)}</button>`,
    )
    .join("");
  const minutes = currentMinutes();

  return `<section class="page timer-page">
    <div class="page-head">
      <h1>专注</h1>
      <button class="btn" data-action="add-session">补记专注</button>
    </div>
    <div class="timer-split">
      <div class="timer-setup">
        <div class="timer-block">
          <h2>科目</h2>
          <div class="chips">
            ${chips}
            <button class="chip add-chip" data-action="add-subject">+ 添加种类</button>
          </div>
        </div>
        <div class="timer-block">
          <h2>方式</h2>
          <div class="seg">
            <button data-action="mode" data-mode="countdown" aria-pressed="${t.mode === "countdown"}">倒计时</button>
            <button data-action="mode" data-mode="countup" aria-pressed="${t.mode === "countup"}">正计时</button>
          </div>
        </div>
        ${
          t.mode === "countdown"
            ? `<div class="timer-block">
              <h2>阶段</h2>
              <div class="seg">
                <button data-action="kind" data-kind="focus" aria-pressed="${t.kind === "focus"}">专注</button>
                <button data-action="kind" data-kind="shortBreak" aria-pressed="${t.kind === "shortBreak"}">短休</button>
                <button data-action="kind" data-kind="longBreak" aria-pressed="${t.kind === "longBreak"}">长休</button>
              </div>
            </div>
            <div class="timer-block">
              <h2>时长</h2>
              <div class="stepper">
                <button data-action="duration" data-delta="-5" aria-label="减 5 分钟" ${running ? "disabled" : ""}>-5</button>
                <button data-action="duration" data-delta="-1" aria-label="减 1 分钟" ${running ? "disabled" : ""}>−</button>
                <button class="duration-value" data-action="duration-edit" aria-label="输入分钟数" ${running ? "disabled" : ""}>${minutes}<small>分钟</small></button>
                <button data-action="duration" data-delta="1" aria-label="加 1 分钟" ${running ? "disabled" : ""}>+</button>
                <button data-action="duration" data-delta="5" aria-label="加 5 分钟" ${running ? "disabled" : ""}>+5</button>
              </div>
            </div>`
            : ""
        }
      </div>
      <div class="timer-stage">
        <div class="timer-face">
        <div class="ring-slot">${timerRingHtml(shown, progress)}</div>
        <div class="actions">
          ${
            running
              ? `<button class="btn primary" data-action="pause"><span class="icon icon-pause" aria-hidden="true"></span>暂停</button>`
              : `<button class="btn primary" data-action="start"><span class="icon icon-play" aria-hidden="true"></span>${t.run === "paused" ? "继续" : "开始"}</button>`
          }
          ${
            t.mode === "countup" && t.run !== "idle"
              ? `<button class="btn" data-action="finish-up">结束并记录</button>`
              : ""
          }
          <button class="btn" data-action="reset">重置</button>
          ${
            t.taskTitle
              ? `<button class="btn ghost" data-action="clear-task" ${running ? "disabled" : ""}>取消任务</button>`
              : ""
          }
        </div>
        </div>
      </div>
    </div>
  </section>`;
}

function renderBars(items, colorOf) {
  const max = items.reduce((m, [, v]) => Math.max(m, v), 0);
  if (!items.length || max === 0) return `<div class="empty">这个时间段还没有专注记录</div>`;
  return items
    .map(([name, sec], index) => {
      const pct = max ? Math.round((sec / max) * 100) : 0;
      const color = colorOf ? colorOf(name) : PALETTE_IDS[index % PALETTE_IDS.length];
      return `<div class="bar-row">
        <div class="bar-top"><span>${esc(name)}</span><span>${formatFocus(sec)}</span></div>
        <div class="bar"><i style="width:${pct}%;--tone:${colorRgb(color)}"></i></div>
      </div>`;
    })
    .join("");
}

function percentShares(values) {
  const total = values.reduce((sum, value) => sum + value, 0);
  if (!total) return values.map(() => 0);
  const raw = values.map((value) => (value / total) * 100);
  const floors = raw.map((value) => Math.floor(value + 1e-9));
  let leftover = 100 - floors.reduce((sum, value) => sum + value, 0);
  const order = raw
    .map((value, index) => ({ index, frac: value - floors[index] }))
    .sort((a, b) => b.frac - a.frac);
  const shares = floors.slice();
  for (let step = 0; step < leftover; step += 1) shares[order[step % order.length].index] += 1;
  return shares;
}

function piePoint(cx, cy, r, angle) {
  const rad = ((angle - 90) * Math.PI) / 180;
  return [cx + r * Math.cos(rad), cy + r * Math.sin(rad)];
}

function donutPath(cx, cy, outer, inner, start, end) {
  const sweep = end - start;
  if (sweep >= 359.999) {
    return `M ${cx} ${cy - outer} A ${outer} ${outer} 0 1 1 ${cx} ${cy + outer} A ${outer} ${outer} 0 1 1 ${cx} ${cy - outer} M ${cx} ${cy - inner} A ${inner} ${inner} 0 1 0 ${cx} ${cy + inner} A ${inner} ${inner} 0 1 0 ${cx} ${cy - inner}`;
  }
  const [ox1, oy1] = piePoint(cx, cy, outer, start);
  const [ox2, oy2] = piePoint(cx, cy, outer, end);
  const [ix2, iy2] = piePoint(cx, cy, inner, end);
  const [ix1, iy1] = piePoint(cx, cy, inner, start);
  const large = sweep > 180 ? 1 : 0;
  return `M ${ox1.toFixed(2)} ${oy1.toFixed(2)} A ${outer} ${outer} 0 ${large} 1 ${ox2.toFixed(2)} ${oy2.toFixed(2)} L ${ix2.toFixed(2)} ${iy2.toFixed(2)} A ${inner} ${inner} 0 ${large} 0 ${ix1.toFixed(2)} ${iy1.toFixed(2)} Z`;
}

function renderPie(items, colorOf) {
  const rows = items.filter(([, sec]) => sec > 0);
  const total = rows.reduce((sum, [, sec]) => sum + sec, 0);
  if (!rows.length || !total) return `<div class="empty">这个时间段还没有专注记录</div>`;
  const shares = percentShares(rows.map(([, sec]) => sec));
  const cx = 100;
  const cy = 100;
  const outer = 90;
  const inner = 52;
  const gap = rows.length > 1 ? 1.4 : 0;
  let cursor = 0;
  const slices = rows
    .map(([name, sec], index) => {
      const color = colorOf ? colorOf(name) : PALETTE_IDS[index % PALETTE_IDS.length];
      const sweep = (sec / total) * 360;
      const start = cursor + gap / 2;
      const end = cursor + sweep - gap / 2;
      cursor += sweep;
      const mid = (start + end) / 2;
      const [lx, ly] = piePoint(cx, cy, (outer + inner) / 2, mid);
      const label =
        shares[index] >= 8
          ? `<text class="pie-label" x="${lx.toFixed(1)}" y="${ly.toFixed(1)}" text-anchor="middle" dominant-baseline="middle">${shares[index]}%</text>`
          : "";
      return `<path class="pie-slice" fill-rule="evenodd" style="--tone:${colorRgb(color)}" d="${donutPath(cx, cy, outer, inner, start, Math.max(start, end))}"><title>${esc(name)} ${formatFocus(sec)} · ${shares[index]}%</title></path>${label}`;
    })
    .join("");
  const legend = rows
    .map(([name, sec], index) => {
      const color = colorOf ? colorOf(name) : PALETTE_IDS[index % PALETTE_IDS.length];
      return `<li>
        <i class="color-dot" style="--tone:${colorRgb(color)}" aria-hidden="true"></i>
        <span>${esc(name)}</span>
        <span class="pie-dur">${formatFocus(sec)}</span>
        <em>${shares[index]}%</em>
      </li>`;
    })
    .join("");
  return `<div class="pie-panel">
    <svg class="pie-chart" viewBox="0 0 200 200" role="img" aria-label="各科目占比">
      ${slices}
      <circle class="pie-cover" cx="100" cy="100" r="71" pathLength="1" aria-hidden="true"></circle>
    </svg>
    <ul class="pie-legend">${legend}</ul>
  </div>`;
}

function scheduleView() {
  const view = state.ui.scheduleView;
  return view === "week" || view === "month" ? view : "day";
}

function shiftScheduleDate(days) {
  const next = parseDayKey(state.ui.scheduleDate);
  next.setDate(next.getDate() + days);
  state.ui.scheduleDate = dayKey(next);
  render();
}

function shiftScheduleMonth(delta) {
  const date = parseDayKey(state.ui.scheduleDate);
  const day = date.getDate();
  date.setDate(1);
  date.setMonth(date.getMonth() + delta);
  const last = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  date.setDate(Math.min(day, last));
  state.ui.scheduleDate = dayKey(date);
  render();
}

function startOfWeek(dateKey) {
  const date = parseDayKey(dateKey);
  const offset = date.getDay() === 0 ? -6 : 1 - date.getDay();
  date.setDate(date.getDate() + offset);
  return dayKey(date);
}

function weekKeys(dateKey) {
  const start = parseDayKey(startOfWeek(dateKey));
  return Array.from({ length: 7 }, (_, index) => {
    const next = new Date(start);
    next.setDate(start.getDate() + index);
    return dayKey(next);
  });
}

function formatWeekRange(keys) {
  const start = parseDayKey(keys[0]);
  const end = parseDayKey(keys[6]);
  const left = `${start.getMonth() + 1}月${start.getDate()}日`;
  const right =
    start.getMonth() === end.getMonth()
      ? `${end.getDate()}日`
      : `${end.getMonth() + 1}月${end.getDate()}日`;
  return `${left}-${right}`;
}

function formatMonthLabel(date) {
  const now = new Date();
  const month = `${date.getMonth() + 1}月`;
  return date.getFullYear() === now.getFullYear() ? month : `${date.getFullYear()}年${month}`;
}

function shiftDayKey(dateKey, { days = 0, months = 0, years = 0 } = {}) {
  const date = parseDayKey(dateKey);
  if (years) {
    const day = date.getDate();
    date.setDate(1);
    date.setFullYear(date.getFullYear() + years);
    const last = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
    date.setDate(Math.min(day, last));
  }
  if (months) {
    const day = date.getDate();
    date.setDate(1);
    date.setMonth(date.getMonth() + months);
    const last = new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
    date.setDate(Math.min(day, last));
  }
  if (days) date.setDate(date.getDate() + days);
  return dayKey(date);
}

function statsDateNavHtml() {
  const period = state.ui.statsPeriod;
  if (period === "all") return "";
  const dateKey = state.ui.statsDate || dayKey();
  const date = parseDayKey(dateKey);
  const today = dayKey();
  const now = new Date();
  const week = weekKeys(dateKey);
  const weekday = WEEKDAY_LABEL[date.getDay()];
  const monthDay = `${date.getMonth() + 1}月${date.getDate()}日`;
  const isToday = dateKey === today;
  const isThisWeek = startOfWeek(dateKey) === startOfWeek(today);
  const isThisMonth = date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth();
  const isThisYear = date.getFullYear() === now.getFullYear();
  const pill =
    period === "week"
      ? `<button class="date-pill" data-action="stats-today" ${isThisWeek ? "disabled" : ""}>
          <strong>${isThisWeek ? "本周" : formatWeekRange(week)}</strong>
          <span>${isThisWeek ? formatWeekRange(week) : "回本周"}</span>
        </button>`
      : period === "month"
        ? `<button class="date-pill" data-action="stats-today" ${isThisMonth ? "disabled" : ""}>
          <strong>${isThisMonth ? "本月" : formatMonthLabel(date)}</strong>
          <span>${isThisMonth ? formatMonthLabel(date) : "回本月"}</span>
        </button>`
        : period === "year"
          ? `<button class="date-pill" data-action="stats-today" ${isThisYear ? "disabled" : ""}>
          <strong>${isThisYear ? "今年" : `${date.getFullYear()}年`}</strong>
          <span>${isThisYear ? `${date.getFullYear()}年` : "回今年"}</span>
        </button>`
          : `<button class="date-pill" data-action="stats-today" ${isToday ? "disabled" : ""}>
          <strong>${isToday ? "今天" : monthDay}</strong>
          <span>周${weekday}${isToday ? "" : " · 回今天"}</span>
        </button>`;
  const arrow =
    period === "week"
      ? ["上一周", "下一周"]
      : period === "month"
        ? ["上一月", "下一月"]
        : period === "year"
          ? ["上一年", "下一年"]
          : ["前一天", "后一天"];
  return `<div class="schedule-date-nav">
    <button class="nav-arrow" data-action="stats-prev" aria-label="${arrow[0]}">‹</button>
    ${pill}
    <button class="nav-arrow" data-action="stats-next" aria-label="${arrow[1]}">›</button>
  </div>`;
}

function monthGridKeys(dateKey) {
  const cursor = parseDayKey(dateKey);
  const first = dayKey(new Date(cursor.getFullYear(), cursor.getMonth(), 1));
  const start = parseDayKey(startOfWeek(first));
  return Array.from({ length: 42 }, (_, index) => {
    const next = new Date(start);
    next.setDate(start.getDate() + index);
    return dayKey(next);
  });
}

function hourGutterHtml() {
  const startHour = DAY_START / 60;
  const hours = (DAY_END - DAY_START) / 60;
  return Array.from({ length: hours + 1 }, (_, index) => {
    const hour = startHour + index;
    return `<span class="hour-label" style="top:${(index / hours) * 100}%">${String(hour).padStart(2, "0")}</span>`;
  }).join("");
}

function hourSlotsHtml(nowMin, highlight) {
  const startHour = DAY_START / 60;
  const hours = (DAY_END - DAY_START) / 60;
  return Array.from({ length: hours }, (_, index) => {
    const hour = startHour + index;
    const current = highlight && Math.floor(nowMin / 60) === hour;
    return `<div class="hour-slot${current ? " is-now" : ""}" style="top:${(index / hours) * 100}%;height:${100 / hours}%"></div>`;
  }).join("");
}

function planTightness(block) {
  const mins = Math.max(0, block.viewEnd - block.viewStart);
  if (mins <= 25) return "tiny";
  if (mins <= 45) return "short";
  return "";
}

function planBlockHtml(block, compact) {
  const top = dayPct(block.viewStart);
  const bottom = 100 - dayPct(block.viewEnd);
  const gap = compact ? 3 : 6;
  const width = `calc((100% - ${(block.lanes - 1) * gap}px) / ${block.lanes})`;
  const left = `calc(${block.lane} * ((100% - ${(block.lanes - 1) * gap}px) / ${block.lanes} + ${gap}px))`;
  const action =
    block.source === "plan" || block.source === "commute"
      ? `data-action="edit-plan" data-id="${block.planId || block.id}"`
      : "";
  const repeatText = block.source === "plan" ? formatRepeat(block) : "";
  const meta = [
    `${formatHm(block.startMin)}-${formatHm(block.endMin)}`,
    block.source === "session" ? "已完成" : "",
    block.source === "commute" ? "通勤" : "",
    block.subjectName || "",
    repeatText,
  ]
    .filter(Boolean)
    .join(" · ");
  const color = colorOfPlan(block);
  const checked = block.source === "plan" && isPlanChecked(block.id, block.occurrenceDate);
  const tight = planTightness(block);
  const hideMeta = compact || Boolean(tight);
  const pctHeight = Math.max(0, ((block.viewEnd - block.viewStart) / DAY_SPAN) * 100);
  const inflate = !compact && Boolean(tight) && block.source === "plan";
  const place = inflate
    ? `top:${top}%;height:max(${pctHeight}%, 44px)`
    : `top:${top}%;bottom:${bottom}%`;
  const label =
    block.source === "commute"
      ? ""
      : `<strong>${esc(block.title)}</strong>${hideMeta ? "" : `<span>${esc(meta)}</span>`}`;
  return `<button class="plan-block ${block.source}${compact ? " compact" : ""}${tight ? ` ${tight}` : ""}${checked ? " is-checked" : ""}" style="${place};left:${left};width:${width};--tone:${colorRgb(color)}" title="${esc(block.title)} ${esc(meta)}" ${action} data-date="${block.occurrenceDate || ""}">
    ${checked ? '<span class="plan-done-mark" aria-hidden="true">✓</span>' : ""}${label}
  </button>`;
}

function nearestPlanId(event, root) {
  const x = event.clientX;
  const y = event.clientY;
  let bestId = "";
  let bestDist = 22;
  root.querySelectorAll(".plan-block.plan, .plan-block.commute").forEach((node) => {
    const box = node.getBoundingClientRect();
    const dx = x < box.left ? box.left - x : x > box.right ? x - box.right : 0;
    const dy = y < box.top ? box.top - y : y > box.bottom ? y - box.bottom : 0;
    const dist = Math.hypot(dx, dy);
    if (dist < bestDist) {
      bestDist = dist;
      bestId = node.dataset.id || "";
    }
  });
  return bestId;
}

function commuteBlocks(item) {
  const color = colorOfPlan(item);
  const before = commuteMin(item.commuteBeforeMin);
  const after = commuteMin(item.commuteAfterMin);
  const blocks = [];
  if (before) {
    blocks.push({
      id: `${item.id}-go`,
      planId: item.id,
      title: "去程",
      startMin: item.startMin - before,
      endMin: item.startMin,
      subjectId: item.subjectId,
      subjectName: item.subjectName,
      color,
      source: "commute",
    });
  }
  if (after) {
    blocks.push({
      id: `${item.id}-back`,
      planId: item.id,
      title: "回程",
      startMin: item.endMin,
      endMin: item.endMin + after,
      subjectId: item.subjectId,
      subjectName: item.subjectName,
      color,
      source: "commute",
    });
  }
  return blocks;
}

function dayBlocks(dateKey) {
  return (state.plans || [])
    .filter((item) => planOccursOn(item, dateKey))
    .flatMap((item) => [{ ...item, source: "plan", occurrenceDate: dateKey }, ...commuteBlocks(item)])
    .sort((a, b) => a.startMin - b.startMin);
}

function renderDayBoard(dateKey) {
  const blocks = dayBlocks(dateKey);
  const laid = assignLanes(blocks);
  const nowMin = minutesOf(new Date());
  const nowInView = dateKey === dayKey() && nowMin >= DAY_START && nowMin <= DAY_END;
  return {
    html: `<div class="day-board">
      <div class="hour-gutter" aria-hidden="true">${hourGutterHtml()}</div>
      <div class="day-track" data-action="board-add">
        ${hourSlotsHtml(nowMin, nowInView)}
        ${laid.length ? "" : '<div class="board-hint"><span>点空白时段添加安排</span></div>'}
        ${laid.map((block) => planBlockHtml(block, false)).join("")}
        ${nowInView ? `<div class="now-line" style="top:${dayPct(nowMin)}%"><span>${formatHm(nowMin)}</span></div>` : ""}
      </div>
    </div>`,
  };
}

function renderWeekBoard(dateKey) {
  const today = dayKey();
  const keys = weekKeys(dateKey);
  const nowMin = minutesOf(new Date());
  let hidden = 0;
  const heads = keys
    .map((key) => {
      const date = parseDayKey(key);
      const isToday = key === today;
      return `<button class="week-head${isToday ? " is-today" : ""}" data-action="schedule-day" data-date="${key}">
        <span>周${WEEKDAY_LABEL[date.getDay()]}</span>
        <strong>${date.getDate()}</strong>
      </button>`;
    })
    .join("");
  const cols = keys
    .map((key) => {
      const blocks = dayBlocks(key);
      const laid = assignLanes(blocks);
      hidden += blocks.length - laid.length;
      const nowInView = key === today && nowMin >= DAY_START && nowMin <= DAY_END;
      const add = ` data-action="board-add" data-date="${key}"`;
      return `<div class="week-col${key === today ? " is-today" : ""}"${add}>
        ${hourSlotsHtml(nowMin, nowInView)}
        ${laid.map((block) => planBlockHtml(block, true)).join("")}
        ${nowInView ? `<div class="now-line" style="top:${dayPct(nowMin)}%"></div>` : ""}
      </div>`;
    })
    .join("");
  return {
    hidden,
    html: `<div class="week-board">
      <div class="week-corner" aria-hidden="true"></div>
      <div class="week-heads">${heads}</div>
      <div class="hour-gutter" aria-hidden="true">${hourGutterHtml()}</div>
      <div class="week-grid">${cols}</div>
    </div>`,
  };
}

function renderMonthBoard(dateKey) {
  const today = dayKey();
  const cursor = parseDayKey(dateKey);
  const keys = monthGridKeys(dateKey);
  const heads = WEEKDAY_ORDER.map(
    (day) => `<div class="month-head">周${WEEKDAY_LABEL[day]}</div>`,
  ).join("");
  const cells = keys
    .map((key) => {
      const date = parseDayKey(key);
      const inMonth = date.getMonth() === cursor.getMonth();
      const blocks = dayBlocks(key).filter((block) => block.source !== "commute");
      const visible = blocks.slice(0, 3);
      const more = blocks.length - visible.length;
      const events = visible
        .map((block) => {
          const color = colorOfPlan(block);
          const action =
            block.source === "plan" ? `data-action="edit-plan" data-id="${block.id}" data-date="${key}"` : "disabled";
          const checked = block.source === "plan" && isPlanChecked(block.id, key);
          return `<button class="month-chip ${block.source}${checked ? " is-checked" : ""}" style="--tone:${colorRgb(color)}" title="${esc(block.title)} ${formatHm(block.startMin)}-${formatHm(block.endMin)}" ${action}>${checked ? "✓ " : ""}${esc(block.title)}</button>`;
        })
        .join("");
      return `<div class="month-day${inMonth ? "" : " is-out"}${key === today ? " is-today" : ""}${key === dateKey ? " is-selected" : ""}" data-action="schedule-day" data-date="${key}">
        <strong>${date.getDate()}</strong>
        <div class="month-events">${events}${more ? `<span class="month-more">+${more}</span>` : ""}</div>
      </div>`;
    })
    .join("");
  return {
    hidden: 0,
    html: `<div class="month-board">
      <div class="month-heads">${heads}</div>
      <div class="month-grid">${cells}</div>
    </div>`,
  };
}

function renderWeekList(dateKey) {
  const days = weekKeys(dateKey).map((key) => {
    const date = parseDayKey(key);
    const plans = state.plans.filter((item) => planOccursOn(item, key)).sort((a, b) => a.startMin - b.startMin);
    const items = plans.length
      ? plans.map((plan) => {
          const checked = isPlanChecked(plan.id, key);
          return `<button class="week-list-item${checked ? " is-checked" : ""}" data-action="edit-plan" data-id="${plan.id}" data-date="${key}" style="--tone:${colorRgb(colorOfPlan(plan))}"><span>${formatHm(plan.startMin)}</span><strong>${esc(plan.title)}</strong>${checked ? '<span aria-label="已完成">✓</span>' : ""}</button>`;
        }).join("")
      : '<span class="week-list-empty">没有安排</span>';
    return `<section class="week-list-day">
      <button class="week-list-date" data-action="schedule-day" data-date="${key}"><span>周${WEEKDAY_LABEL[date.getDay()]}</span><strong>${date.getMonth() + 1}月${date.getDate()}日</strong></button>
      <div class="week-list-items">${items}</div>
    </section>`;
  }).join("");
  return `<div class="week-list">${days}</div>`;
}

function renderToday() {
  const view = scheduleView();
  const dateKey = state.ui.scheduleDate || dayKey();
  const date = parseDayKey(dateKey);
  const today = dayKey();
  const now = new Date();
  const week = weekKeys(dateKey);
  const weekday = WEEKDAY_LABEL[date.getDay()];
  const monthDay = `${date.getMonth() + 1}月${date.getDate()}日`;
  const isToday = dateKey === today;
  const isThisWeek = startOfWeek(dateKey) === startOfWeek(today);
  const isThisMonth = date.getFullYear() === now.getFullYear() && date.getMonth() === now.getMonth();
  const heading = view === "day"
    ? isToday ? "今天的安排" : `${monthDay}的安排`
    : view === "week"
      ? isThisWeek ? "本周安排" : `${formatWeekRange(week)}的安排`
      : isThisMonth ? "本月安排" : `${formatMonthLabel(date)}的安排`;
  const plans = state.plans
    .filter((item) => planOccursOn(item, dateKey))
    .sort((a, b) => a.startMin - b.startMin || a.endMin - b.endMin);
  const doneCount = plans.filter((item) => isPlanChecked(item.id, dateKey)).length;
  const nextPlan = isToday ? plans.find((item) => !isPlanChecked(item.id, dateKey) && item.endMin > minutesOf(now)) : null;
  const nextText = nextPlan ? `接下来 ${formatHm(nextPlan.startMin)} · ${nextPlan.title}` : isToday ? (plans.length ? "今天的安排都已结束" : "今天还没有安排") : "按时间查看这一天";
  const pill =
    view === "week"
      ? `<button class="date-pill" data-action="schedule-today" ${isThisWeek ? "disabled" : ""}>
          <strong>${isThisWeek ? "本周" : formatWeekRange(week)}</strong>
          <span>${isThisWeek ? formatWeekRange(week) : "回本周"}</span>
        </button>`
      : view === "month"
        ? `<button class="date-pill" data-action="schedule-today" ${isThisMonth ? "disabled" : ""}>
            <strong>${isThisMonth ? "本月" : formatMonthLabel(date)}</strong>
            <span>${isThisMonth ? formatMonthLabel(date) : "回本月"}</span>
          </button>`
        : `<button class="date-pill" data-action="schedule-today" ${isToday ? "disabled" : ""}>
            <strong>${isToday ? "今天" : monthDay}</strong>
            <span>周${weekday}${isToday ? "" : " · 回今天"}</span>
          </button>`;
  const arrowLabel =
    view === "week" ? ["上一周", "下一周"] : view === "month" ? ["上一月", "下一月"] : ["前一天", "后一天"];
  const agenda = plans.length
    ? plans.map((plan) => {
        const checked = isPlanChecked(plan.id, dateKey);
        const details = [plan.subjectName, formatRepeat(plan)].filter(Boolean).join(" · ");
        return `<article class="agenda-item${checked ? " is-checked" : ""}" style="--tone:${colorRgb(colorOfPlan(plan))}">
          <div class="agenda-time"><strong>${formatHm(plan.startMin)}</strong><span>${formatHm(plan.endMin)}</span></div>
          <button type="button" class="agenda-main" data-action="edit-plan" data-id="${plan.id}" data-date="${dateKey}">
            <strong>${esc(plan.title)}</strong>${details ? `<span>${esc(details)}</span>` : ""}
          </button>
          <button type="button" class="agenda-check" data-action="toggle-plan-check" data-id="${plan.id}" data-date="${dateKey}" aria-pressed="${checked}" aria-label="${checked ? "取消完成" : "标记完成"}：${esc(plan.title)}">
            ${checked ? '<span class="icon icon-check" aria-hidden="true"></span>' : ""}
          </button>
        </article>`;
      }).join("")
    : `<div class="today-empty"><strong>这一天还没有安排</strong><span>添加一段有开始和结束时间的安排。</span><button class="btn" data-action="add-plan">添加安排</button></div>`;
  const dayContent = `<div class="today-layout">
    <section class="today-timeline">
      <div class="today-section-head"><h2>时间轴</h2><span>07:00—23:00</span></div>
      ${renderDayBoard(dateKey).html}
    </section>
    <section class="today-agenda">
      <div class="today-section-head"><h2>${isToday ? "今日安排" : `${monthDay}安排`}</h2><span>${doneCount}/${plans.length} 已完成</span></div>
      <div class="agenda-list">${agenda}</div>
    </section>
  </div>`;
  const calendar = view === "week" ? renderWeekBoard(dateKey) : renderMonthBoard(dateKey);
  return `<section class="page schedule-page today-page">
    <header class="today-header">
      <div class="today-heading"><span class="eyebrow">FOCUSPAD / 日程</span><h1>${heading}</h1><p>${view === "day" ? esc(nextText) : "选一天，查看安排并手动标记完成。"}</p></div>
      <button class="btn primary today-add" data-action="add-plan"><span class="icon icon-plus" aria-hidden="true"></span>新建安排</button>
    </header>
    <div class="today-toolbar">
      <div class="seg schedule-view" aria-label="日程视图">
        <button data-action="schedule-view" data-view="day" aria-pressed="${view === "day"}">日</button>
        <button data-action="schedule-view" data-view="week" aria-pressed="${view === "week"}">周</button>
        <button data-action="schedule-view" data-view="month" aria-pressed="${view === "month"}">月</button>
      </div>
      <div class="schedule-date-nav">
        <button class="nav-arrow" data-action="schedule-prev" aria-label="${arrowLabel[0]}">‹</button>
        ${pill}
        <button class="nav-arrow" data-action="schedule-next" aria-label="${arrowLabel[1]}">›</button>
      </div>
    </div>
    ${view === "day" ? dayContent : `<div class="today-calendar">${calendar.html}${view === "week" ? renderWeekList(dateKey) : ""}</div>`}
  </section>`;
}

function renderStats() {
  const bundle = statsBundle();
  const period = state.ui.statsPeriod;
  const [from, to] = rangeFor(period);
  const records = state.sessions
    .filter((item) => item.kind === "focus" && item.completed && item.startedAt >= from && item.startedAt < to)
    .sort((a, b) => b.startedAt - a.startedAt);
  const recordHtml = records.slice(0, 40).map((item) => {
    const date = new Date(item.startedAt);
    const key = dayKey(date);
    const label = `${date.getMonth() + 1}月${date.getDate()}日 · ${formatHm(minutesOf(date))}`;
    return `<button class="record-row" data-action="open-session-day" data-date="${key}"><span><strong>${esc(item.subjectName || "专注")}</strong><small>${label}</small></span><b>${formatFocus(item.durationSec)}</b></button>`;
  }).join("");
  return `<section class="page stats-page">
    <div class="page-head">
      <h1>专注统计</h1>
      <button class="btn" data-action="add-session">补记专注</button>
    </div>
    <div class="stats-toolbar">
      <div class="seg stats-period">
        <button data-action="period" data-period="day" aria-pressed="${period === "day"}">日</button>
        <button data-action="period" data-period="week" aria-pressed="${period === "week"}">周</button>
        <button data-action="period" data-period="month" aria-pressed="${period === "month"}">月</button>
        <button data-action="period" data-period="year" aria-pressed="${period === "year"}">年</button>
        <button data-action="period" data-period="all" aria-pressed="${period === "all"}">总计</button>
      </div>
      ${statsDateNavHtml()}
    </div>
    <div class="stats-grid">
      <article class="stat-card"><span class="muted">专注时长</span><strong>${formatFocus(bundle.focusSeconds)}</strong></article>
      <article class="stat-card"><span class="muted">完成次数</span><strong>${bundle.focusCount} 次</strong></article>
    </div>
    ${period === "day" ? `<div class="goal-meter"><span>今日目标</span><div class="goal-track"><i style="width:${Math.min(100, (bundle.focusCount / Math.max(1, state.settings.dailyGoal)) * 100)}%"></i></div><strong>${bundle.focusCount} / ${state.settings.dailyGoal}</strong></div>` : ""}
    <div class="stats-split">
      <div class="stats-col stats-col-left${period === "all" ? " has-year" : ""}">
        <section class="stats-panel">
          <h2>各科目时长</h2>
          <div class="stats-panel-body">${renderBars(bundle.bySubject, (name) => colorOfSubject(null, name))}</div>
        </section>
        <section class="stats-panel">
          <h2>各时段时长</h2>
          <div class="stats-panel-body">${renderBars(bundle.bySlot)}</div>
        </section>
        ${
          period === "all"
            ? `<section class="stats-panel">
          <h2>各年时长</h2>
          <div class="stats-panel-body">${renderBars(bundle.byYear)}</div>
        </section>`
            : ""
        }
      </div>
      <section class="stats-col stats-col-right stats-panel stats-panel-pie">
        <h2>各科目占比</h2>
        <div class="stats-panel-body">${renderPie(bundle.bySubject, (name) => colorOfSubject(null, name))}</div>
      </section>
    </div>
    <section class="stats-records"><div class="today-section-head"><h2>专注记录</h2><span>${records.length > 40 ? `最近 40 条 / 共 ${records.length} 条` : `共 ${records.length} 条`}</span></div><div class="record-list">${recordHtml || '<p class="empty">这个时间段还没有专注记录</p>'}</div></section>
  </section>`;
}

function stepper(key, label, min, max) {
  const value = state.settings[key];
  return `<div class="setting-row">
    <span>${label}</span>
    <div class="stepper">
      <button data-action="step" data-key="${key}" data-delta="-1" data-min="${min}" data-max="${max}">-</button>
      <b>${value}</b>
      <button data-action="step" data-key="${key}" data-delta="1" data-min="${min}" data-max="${max}">+</button>
    </div>
  </div>`;
}

function renderSettings() {
  const theme = state.settings.themeMode;
  const subjects = state.subjects.map((subject) => `<div class="subject-setting" style="--tone:${colorRgb(subject.color)}">
    <span class="subject-setting-dot" aria-hidden="true"></span>
    <button data-action="edit-subject" data-id="${subject.id}"><strong>${esc(subject.name)}</strong><span>${subject.minutes} 分钟</span></button>
    <button class="subject-setting-edit" data-action="edit-subject" data-id="${subject.id}" aria-label="编辑${esc(subject.name)}">编辑</button>
    <button class="subject-setting-delete" data-action="delete-subject" data-id="${subject.id}" aria-label="删除${esc(subject.name)}" ${state.subjects.length <= 1 ? "disabled" : ""}>删除</button>
  </div>`).join("");
  return `<section class="page">
    <div class="page-head"><h1>设置</h1></div>
    <div class="stack">
      <section class="settings-group">
        <h2>计时</h2>
        ${stepper("focusMinutes", "默认专注（分钟）", 1, 180)}
        ${stepper("shortBreakMinutes", "短休息（分钟）", 1, 60)}
        ${stepper("longBreakMinutes", "长休息（分钟）", 1, 120)}
        ${stepper("cyclesBeforeLongBreak", "长休息间隔（次）", 2, 12)}
        ${stepper("dailyGoal", "每日目标（次）", 1, 30)}
      </section>
      <section class="settings-group">
        <h2>计时种类</h2>
        <div class="subject-settings">${subjects}</div>
        <button class="btn" data-action="add-subject">添加种类</button>
      </section>
      <section class="settings-group">
        <h2>外观</h2>
        <div class="seg">
          <button data-action="theme" data-theme="system" aria-pressed="${theme === "system"}">跟随系统</button>
          <button data-action="theme" data-theme="light" aria-pressed="${theme === "light"}">浅色</button>
          <button data-action="theme" data-theme="dark" aria-pressed="${theme === "dark"}">深色</button>
        </div>
      </section>
      <section class="settings-group">
        <h2>云同步</h2>
        ${syncSettingsHtml()}
      </section>
      <section class="settings-group">
        <h2>在线更新</h2>
        ${updateSettingsHtml()}
      </section>
      <section class="settings-group">
        <h2>数据</h2>
        <button class="btn danger" data-action="reset-data">清空本地数据</button>
      </section>
    </div>
  </section>`;
}

function syncSettingsHtml() {
  const device = state.settings.syncDevice === "phone" ? "phone" : "tablet";
  const token = state.settings.githubToken || "";
  const when = state.settings.lastSyncAt
    ? new Date(state.settings.lastSyncAt).toLocaleString("zh-CN", {
        month: "numeric",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "";
  const status =
    state.ui.syncStatus ||
    (when
      ? `上次同步 ${when}`
      : "第一次用平板当底稿。手机若还是演示数据，只会拉取，不会盖掉平板。");
  return `
    <div class="seg">
      <button data-action="sync-device" data-device="phone" aria-pressed="${device === "phone"}">这台是手机</button>
      <button data-action="sync-device" data-device="tablet" aria-pressed="${device === "tablet"}">这台是平板</button>
    </div>
    <input class="field" data-field="githubToken" type="password" autocomplete="off" placeholder="GitHub 令牌（勾选 gist）" value="${esc(token)}" aria-label="GitHub 令牌" />
    <p class="muted">打开软件会自动同步：先把云端记录拉下来合并，再把这台的改动传回去。</p>
    ${cloudHintHtml()}
    <button class="btn primary" data-action="sync-now"${cloudBusy ? " disabled" : ""}>${cloudBusy ? "正在同步…" : "立即同步"}</button>
    ${isNativeTablet() ? `<button class="btn" data-action="sync-seed-tablet"${cloudBusy ? " disabled" : ""}>用这台平板覆盖云端</button>` : ""}
    ${isPhoneDevice() && isNativeApp() ? `<button class="btn" data-action="sync-pull-phone"${cloudBusy ? " disabled" : ""}>用云端覆盖这台手机</button>` : ""}
    <p class="muted">${esc(status)}</p>
  `;
}

function nativeUpdateState() {
  try {
    const raw = window.FocusPad?.getUpdateState?.();
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function updateSettingsHtml() {
  const native = nativeUpdateState();
  const url = resolvedUpdateUrl(state.settings.updateUrl || native?.updateUrl);
  const installed = native?.installedVersion;
  const version =
    installed != null && String(installed) !== "" && String(installed) !== "—"
      ? String(installed)
      : String(WEB_VERSION);
  const remote = state.ui.remoteVersion;
  const versionLabel =
    remote && String(remote) !== String(version) ? `这台 v${version} · 线上 v${remote}` : `v${version}`;
  const status = state.ui.updateStatus || native?.message || "";
  return `
    <div class="update-url-row">
      <input class="field" data-field="updateUrl" type="url" inputmode="url" placeholder="${esc(DEFAULT_UPDATE_URL)}" value="${esc(url)}" aria-label="更新地址" />
      <span class="update-ver">${esc(versionLabel)}</span>
    </div>
    <p class="muted">打开软件会自动检查更新。「这台」是已经装上的网页版本，「线上」是服务器最新版。</p>
    <button class="btn primary" data-action="check-update">${native?.busy ? "正在检查…" : "检查并更新"}</button>
    ${status ? `<p class="muted">${esc(status)}</p>` : ""}
  `;
}

function renderModal() {
  const modal = state.ui.modal;
  if (!modal) return "";
  if (modal.type === "plan") {
    const plan = modal.planId ? state.plans.find((item) => item.id === modal.planId) : null;
    const dateKey = state.ui.scheduleDate || dayKey();
    const startDefault = plan
      ? formatHm(plan.startMin)
      : formatHm(modal.startMin ?? defaultPlanStart(dateKey));
    const endDefault = plan
      ? formatHm(plan.endMin)
      : formatHm(parseHm(startDefault) + (state.settings.focusMinutes || 25));
    const subjectOptions = [`<option value="">不指定种类</option>`]
      .concat(
        state.subjects.map(
          (item) =>
            `<option value="${item.id}" ${plan?.subjectId === item.id ? "selected" : ""}>${esc(item.name)}</option>`,
        ),
      )
      .join("");
    const repeat = planRepeat(plan);
    const viewDay = parseDayKey(dateKey).getDay();
    const selectedDays = repeat === "weekly" && normalizeWeekdays(plan?.weekdays).length
      ? normalizeWeekdays(plan.weekdays)
      : [viewDay];
    const weekdayChecks = WEEKDAY_ORDER.map((day) => {
      const checked = selectedDays.includes(day) ? "checked" : "";
      return `<label class="weekday">
        <input type="checkbox" name="weekday" value="${day}" ${checked} />
        <span>${WEEKDAY_LABEL[day]}</span>
      </label>`;
    }).join("");
    const planColor = colorOfPlan(plan) || nextFreeColor();
    return `<div class="modal-bg">
      <form class="modal" data-form="plan" data-id="${plan?.id || ""}">
        <h2>${plan ? "编辑安排" : "添加安排"}</h2>
        <input class="field" name="title" placeholder="例如 背单词、写作业" value="${esc(plan?.title || "")}" autofocus />
        <label class="muted field-label">开始</label>
        ${timeWheelHtml("start", modalTime("start", startDefault))}
        <label class="muted field-label">结束</label>
        ${timeWheelHtml("end", modalTime("end", endDefault))}
        <div class="commute-fields">
          <label>
            <span class="muted field-label">去程通勤（分钟）</span>
            <input class="field" name="commuteBefore" type="number" min="0" max="180" step="5" value="${commuteMin(plan?.commuteBeforeMin)}" />
          </label>
          <label>
            <span class="muted field-label">回程通勤（分钟）</span>
            <input class="field" name="commuteAfter" type="number" min="0" max="180" step="5" value="${commuteMin(plan?.commuteAfterMin)}" />
          </label>
        </div>
        <p class="muted session-hint">去程画在开始前，回程画在结束后。填 0 就是没有通勤。</p>
        <label class="muted field-label">计时种类</label>
        <select class="field" name="subjectId">${subjectOptions}</select>
        <label class="muted field-label">颜色</label>
        ${colorSwatches("color", planColor)}
        <label class="muted field-label">重复</label>
        <div class="repeat-options">
          <label class="repeat-opt">
            <input type="radio" name="repeat" value="none" ${repeat === "none" ? "checked" : ""} />
            <span>不重复</span>
          </label>
          <label class="repeat-opt">
            <input type="radio" name="repeat" value="daily" ${repeat === "daily" ? "checked" : ""} />
            <span>每天</span>
          </label>
          <label class="repeat-opt">
            <input type="radio" name="repeat" value="weekly" ${repeat === "weekly" ? "checked" : ""} />
            <span>每周</span>
          </label>
        </div>
        <div class="weekdays" ${repeat === "weekly" ? "" : "hidden"}>
          ${weekdayChecks}
        </div>
        <div class="row" style="justify-content:flex-end">
          ${plan ? `<button type="button" class="btn" data-action="delete-plan" data-id="${plan.id}">删除</button>` : ""}
          <button type="button" class="btn" data-action="close-modal">取消</button>
          <button class="btn primary" type="submit">保存</button>
        </div>
      </form>
    </div>`;
  }
  if (modal.type === "session-form") {
    const date = modal.date || dayKey();
    const subjectId = modal.subjectId || state.subjects[0]?.id || "";
    const subjectOptions = state.subjects
      .map(
        (item) =>
          `<option value="${item.id}" ${item.id === subjectId ? "selected" : ""}>${esc(item.name)}</option>`,
      )
      .join("");
    const existing = sessionsOnDate(date)
      .map((item) => {
        const start = minutesOf(new Date(item.startedAt));
        const end = start + Math.max(1, Math.round(item.durationSec / 60));
        const tag = item.manual || item.mode === "manual" ? "补记" : "计时";
        return `<div class="session-log">
          <span>${formatHm(start)}–${formatHm(end)} · ${esc(item.subjectName || "专注")} · ${formatFocus(item.durationSec)} · ${tag}</span>
          <button type="button" class="btn ghost" data-action="delete-session" data-id="${esc(item.id)}">删除</button>
        </div>`;
      })
      .join("");
    return `<div class="modal-bg">
      <form class="modal" data-form="session">
        <h2>补记专注</h2>
        <p class="muted session-hint">选开始和结束时间，记下后这个窗口会关掉。</p>
        <label class="muted field-label">科目</label>
        <select class="field" name="subjectId">${subjectOptions}</select>
        <label class="muted field-label">日期</label>
        <input class="field" name="date" type="date" value="${esc(date)}" />
        <label class="muted field-label">开始时间</label>
        ${timeWheelHtml("start", modalTime("start", modal.startHm || "09:00"))}
        <label class="muted field-label">结束时间</label>
        ${timeWheelHtml("end", modalTime("end", modal.endHm || "09:25"))}
        ${existing ? `<label class="muted field-label">这一天已有</label><div class="session-logs">${existing}</div>` : ""}
        <div class="row" style="justify-content:flex-end">
          <button type="button" class="btn" data-action="close-modal">取消</button>
          <button class="btn primary" type="submit">记下</button>
        </div>
      </form>
    </div>`;
  }
  if (modal.type === "subject-form") {
    const subject = modal.subjectId ? state.subjects.find((item) => item.id === modal.subjectId) : null;
    return `<div class="modal-bg">
      <form class="modal" data-form="subject" data-id="${subject?.id || ""}">
        <h2>${subject ? "编辑计时种类" : "添加计时种类"}</h2>
        <input class="field" name="name" placeholder="名称，例如 听力、阅读" value="${esc(subject?.name || "")}" autofocus />
        <label class="muted field-label">倒计时默认时长（分钟）</label>
        <input class="field" name="minutes" type="number" min="1" max="180" value="${subject?.minutes || state.settings.focusMinutes}" />
        <label class="muted field-label">颜色</label>
        ${colorSwatches("color", resolveColor(subject?.color) || nextFreeColor())}
        <div class="row" style="justify-content:flex-end">
          <button type="button" class="btn" data-action="close-modal">取消</button>
          <button class="btn primary" type="submit">${subject ? "保存" : "添加"}</button>
        </div>
      </form>
    </div>`;
  }
  if (modal.type === "prompt") {
    return `<div class="modal-bg">
      <form class="modal" data-form="${modal.id}">
        <h2>${esc(modal.title)}</h2>
        <input class="field" name="text" value="${esc(modal.value || "")}" placeholder="${esc(modal.hint || "")}" autofocus />
        <div class="row" style="justify-content:flex-end">
          <button type="button" class="btn" data-action="close-modal">取消</button>
          <button class="btn primary" type="submit">确定</button>
        </div>
      </form>
    </div>`;
  }
  if (modal.type === "confirm") {
    return `<div class="modal-bg">
      <div class="modal">
        <h2>${esc(modal.title)}</h2>
        <p class="muted" style="margin-bottom:16px">${esc(modal.message)}</p>
        <div class="row" style="justify-content:flex-end">
          <button class="btn" data-action="close-modal">取消</button>
          <button class="btn primary" data-action="confirm-ok">${esc(modal.confirm || "确定")}</button>
        </div>
      </div>
    </div>`;
  }
  if (modal.type === "task") {
    const task = modal.taskId ? state.tasks.find((t) => t.id === modal.taskId) : null;
    const listOptions = state.lists
      .filter((l) => l.system !== "today")
      .map((l) => {
        const selected = (task?.listId || (selectedList().system === "today" ? "inbox" : selectedList().id)) === l.id;
        return `<option value="${l.id}" ${selected ? "selected" : ""}>${esc(l.name)}</option>`;
      })
      .join("");
    return `<div class="modal-bg">
      <form class="modal" data-form="task" data-id="${task?.id || ""}">
        <h2>${task ? "编辑任务" : "添加任务"}</h2>
        <input class="field" name="title" placeholder="标题" value="${esc(task?.title || "")}" autofocus />
        <textarea class="field" name="note" placeholder="备注（可选）">${esc(task?.note || "")}</textarea>
        <select class="field" name="listId">${listOptions}</select>
        <label class="row" style="margin-bottom:16px">
          <input type="checkbox" name="isToday" ${task?.isToday || selectedList().system === "today" ? "checked" : ""} />
          放到今天
        </label>
        <div class="row" style="justify-content:flex-end">
          ${task ? `<button type="button" class="btn" data-action="delete-task" data-id="${task.id}">删除</button>` : ""}
          <button type="button" class="btn" data-action="close-modal">取消</button>
          <button class="btn primary" type="submit">保存</button>
        </div>
      </form>
    </div>`;
  }
  if (modal.type === "list-menu") {
    return `<div class="modal-bg">
      <div class="modal">
        <h2>清单</h2>
        <div class="stack">
          <button class="btn" data-action="rename-list" data-id="${modal.id}">重命名</button>
          <button class="btn" data-action="delete-list" data-id="${modal.id}">删除清单</button>
        </div>
      </div>
    </div>`;
  }
  return "";
}

function paintApp() {
  const samePage = lastRenderedTab === state.ui.tab && !state.ui.timerFull;
  const keepScroll = samePage ? pageScroller()?.scrollTop || 0 : 0;
  if (state.ui.timerFull) {
    root.innerHTML = `${renderFocusFull()}${overlayHtml()}`;
    lastRenderedTab = "timer";
    paintBanner();
    return;
  }
  let shell = root.querySelector(".shell");
  if (!shell) {
    root.innerHTML = `<div class="shell">
    <div class="stage-slot"><main class="stage"></main></div>
    <nav class="nav">${navButtonsHtml()}</nav>
  </div>
  <div class="overlays"></div>`;
    shell = root.querySelector(".shell");
  }
  let slot = shell.querySelector(".stage-slot");
  let main = shell.querySelector(".stage");
  if (!slot && main) {
    slot = document.createElement("div");
    slot.className = "stage-slot";
    main.replaceWith(slot);
    slot.appendChild(main);
  }
  const nav = shell.querySelector(".nav");
  if (main) main.innerHTML = pageHtml();
  syncNav(nav);
  paintOverlays();
  paintBanner();
  lastRenderedTab = state.ui.tab;
  const scroller = pageScroller();
  if (scroller) scroller.scrollTop = keepScroll;
}

function paintAndSettle(prev) {
  paintApp();
  lastSnapshot = snapshotUi();
  afterPaint(prev);
}

function render() {
  const prev = lastSnapshot;
  try {
    applyTheme();
    let kind = inferMotion(prev);
    if (!kind && !prev.boot && document.documentElement.dataset.theme !== prev.theme) {
      kind = "theme";
    }
    const ghostShot =
      kind && kind !== "theme" && kind !== "boot" && kind !== "cover" && !state.ui.timerFull
        ? captureStage()
        : null;
    if (kind && kind !== "theme") interruptMotion();
    if (kind) setMotionMeta(kind, prev);
    paintAndSettle(prev);
    if (ghostShot) mountStageGhost(ghostShot, kind, prev);
    if (kind && kind !== "theme") playPageMotion(kind, prev);
    if (kind) finishMotion(kind);
  } catch (error) {
    console.error(error);
    sanitizeState(state);
    state.ui.timerFull = false;
    state.ui.modal = null;
    if (root) {
      root.innerHTML = `<div class="shell"><main class="page" style="padding:24px">
        <h1>页面刚出错</h1>
        <p class="muted">本地记录还在，没有清空。</p>
        <button class="btn primary" data-action="recover-ui">回到任务</button>
      </main></div>`;
    }
  }
}

function renderTimerOnly() {
  if (!state.ui.timerFull && state.ui.tab !== "timer") return;
  if (state.ui.modal) return;
  const clock = document.querySelector("#clock");
  if (!clock) {
    render();
    return;
  }
  const shown = displayed();
  clock.textContent = formatClock(shown);
  const t = state.timer;
  const progress =
    t.mode === "countup" ? Math.min(1, shown / 3600) : t.targetSec ? 1 - shown / t.targetSec : 0;
  const ring = document.querySelector(".ring-value");
  if (ring) {
    ring.setAttribute("stroke-dasharray", `${CIRC * Math.max(0, Math.min(1, progress))} ${CIRC}`);
  } else if (progress >= 0.02) {
    render();
  }
}

function openPrompt(id, title, hint, value = "") {
  state.ui.modal = { type: "prompt", id, title, hint, value };
  render();
}

function openConfirm(id, title, message, confirm, payload) {
  state.ui.modal = { type: "confirm", id, title, message, confirm, payload };
  render();
}

function finishModal() {
  window.clearTimeout(modalLeaveTimer);
  state.ui.modal = null;
}

function closeModal() {
  window.clearTimeout(modalLeaveTimer);
  const bg = root.querySelector(".modal-bg");
  if (bg && !prefersReducedMotion() && !bg.classList.contains("is-leaving")) {
    bg.classList.remove("is-open");
    bg.classList.add("is-leaving");
    modalLeaveTimer = window.setTimeout(() => {
      state.ui.modal = null;
      render();
    }, 320);
    return;
  }
  state.ui.modal = null;
  render();
}

function syncKeepAwake() {
  try {
    window.FocusPad?.setKeepAwake?.(state.timer.run === "running");
  } catch (_) {
    /* WebView bridge is optional in the browser. */
  }
}

window.focuspadOnUpdate = function focuspadOnUpdate(info) {
  if (!info) return;
  state.ui.updateStatus = info.message || "";
  if (info.message && !info.reloaded) banner(info.message);
  if (state.ui.tab === "settings" && !info.reloaded) render();
};

window.focuspadHandleBack = function focuspadHandleBack() {
  if (state.ui.modal) {
    closeModal();
    return true;
  }
  if (state.ui.timerFull) {
    leaveFocusFull();
    save();
    render();
    return true;
  }
  if (state.ui.listsOpen) {
    state.ui.listsOpen = false;
    render();
    return true;
  }
  return false;
};

function inboxId() {
  return state.lists.find((l) => l.system === "inbox")?.id || "inbox";
}

function taskCardHtml(task, list = selectedList()) {
  const meta = [task.isToday && list.system !== "today" ? "今天" : "", task.note || ""]
    .filter(Boolean)
    .map(esc)
    .join(" / ");
  return `<article class="task-card ${task.done ? "done" : ""}">
            <button class="check" data-action="toggle-done" data-id="${task.id}" aria-label="完成">${task.done ? '<span class="icon icon-check"></span>' : ""}</button>
            <button class="task-body" data-action="edit-task" data-id="${task.id}">
              <div class="task-title">${esc(task.title)}</div>
              ${meta ? `<div class="task-meta">${meta}</div>` : ""}
            </button>
          </article>`;
}

function cleanTaskTitle(text) {
  return String(text || "")
    .replace(/^[\s　]+|[\s　]+$/g, "")
    .replace(
      /^(?:[-*•·]+|第?(?:[0-9０-９]{1,2}|[一二三四五六七八九十]{1,3})(?:[.、．)]|）)|[（(][0-9０-９]{1,2}[)）]|[①②③④⑤⑥⑦⑧⑨⑩])\s*/u,
      "",
    )
    .replace(/[。；;,.，、]+$/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function isLeadLabel(text) {
  const lead = String(text || "").trim();
  return !lead || (/[：:]$/.test(lead) && lead.length <= 12);
}

function splitHomeworkList(text) {
  const marker =
    /(?:[0-9０-９]{1,2}|[一二三四五六七八九十]{1,3})[.、．)](?!\d)|[（(][0-9０-９]{1,2}[)）]|[①②③④⑤⑥⑦⑧⑨⑩]/g;
  const marks = [...String(text || "").matchAll(marker)];
  if (marks.length < 2) return [];
  const parts = [];
  if (!isLeadLabel(text.slice(0, marks[0].index))) {
    parts.push(text.slice(0, marks[0].index));
  }
  for (let i = 0; i < marks.length; i += 1) {
    const start = marks[i].index + marks[i][0].length;
    const end = i + 1 < marks.length ? marks[i + 1].index : text.length;
    parts.push(text.slice(start, end));
  }
  return parts.map(cleanTaskTitle).filter((item) => item.length >= 2);
}

function splitTaskTitles(raw) {
  const text = String(raw || "").replace(/\r/g, "").trim();
  if (!text) return [];
  const listed = splitHomeworkList(text);
  if (listed.length >= 2) return listed.slice(0, 20);
  const lines = text
    .split(/\n+/)
    .map((line) => cleanTaskTitle(line.replace(/^\s*[-*•·]\s*/, "")))
    .filter((item) => item.length >= 2);
  if (lines.length >= 2) return lines.slice(0, 20);
  const clauses = text
    .split(/[。；;]+/)
    .map(cleanTaskTitle)
    .filter((item) => item.length >= 2);
  if (
    clauses.length >= 2 &&
    clauses.length <= 8 &&
    clauses.every((item) => item.length <= 40)
  ) {
    return clauses;
  }
  const single = cleanTaskTitle(text);
  return single ? [single.slice(0, 120)] : [];
}

function addQuickTasks(titles) {
  const list = selectedList();
  const today = list.system === "today";
  const now = Date.now();
  const created = titles
    .map((title) => String(title || "").trim())
    .filter(Boolean)
    .slice(0, 20)
    .map((title, index) => ({
      id: uid(),
      done: false,
      createdAt: now + index,
      completedAt: null,
      title: title.slice(0, 120),
      note: "",
      listId: today ? inboxId() : list.id,
      isToday: today,
      estimatedPomos: 0,
    }));
  if (!created.length) return [];
  state.tasks.push(...created);
  save();
  return created;
}

function finishSplitTasks(created, refresh) {
  const many = created.length > 1;
  if (many) closeComposer();
  if (refresh) {
    focusComposer = composerOpen && !many;
    render();
    if (many) banner(`已拆成 ${created.length} 条任务`);
    return;
  }
  const list = selectedList();
  const composer = root.querySelector(".task-composer");
  created.forEach((task) => composer?.insertAdjacentHTML("beforebegin", taskCardHtml(task, list)));
  if (many) banner(`已拆成 ${created.length} 条任务`);
}

function commitComposer(input, refresh = true) {
  const title = String(input?.value || composerDraft || "").trim();
  if (!title || committingComposer) return false;
  const titles = splitTaskTitles(title);
  if (!titles.length) return false;
  committingComposer = true;
  if (input) input.value = "";
  composerDraft = "";
  const created = addQuickTasks(titles);
  finishSplitTasks(created, refresh);
  committingComposer = false;
  return true;
}

root.addEventListener("input", (event) => {
  if (event.target.id !== "task-composer") return;
  if (!composerOpen || committingComposer) return;
  composerDraft = event.target.value;
});

root.addEventListener("paste", (event) => {
  if (event.target.id !== "task-composer") return;
  const text = event.clipboardData?.getData("text/plain") || "";
  const titles = splitTaskTitles(text);
  if (titles.length < 2 || committingComposer) return;
  event.preventDefault();
  committingComposer = true;
  if (event.target) event.target.value = "";
  closeComposer();
  const created = addQuickTasks(titles);
  finishSplitTasks(created, true);
  committingComposer = false;
});

root.addEventListener("focusout", (event) => {
  if (event.target.id !== "task-composer") return;
  if (committingComposer || !composerOpen) return;
  if (event.relatedTarget?.closest?.("[data-action=open-composer]")) return;
  if (!String(event.target.value || "").trim()) {
    closeComposer();
    render();
    return;
  }
  closeComposer();
  commitComposer(event.target, true);
});

root.addEventListener("change", (event) => {
  const target = event.target;
  if (target.dataset.field === "updateUrl") {
    state.settings.updateUrl = resolvedUpdateUrl(target.value);
    save();
    try {
      window.FocusPad?.setUpdateUrl?.(state.settings.updateUrl);
    } catch (_) {}
    return;
  }
  if (target.dataset.field === "githubToken") {
    state.settings.githubToken = target.value.trim();
    state.settings.gistId = "";
    saveLocalOnly();
    if (state.settings.githubToken) cloudSync({ silent: true });
    return;
  }
  if (target.name === "repeat" && target.form) {
    const weekdays = target.form.querySelector(".weekdays");
    if (weekdays) weekdays.hidden = target.value !== "weekly";
  }
  if (state.ui.modal?.type === "session-form" && target.form?.dataset.form === "session") {
    const form = target.form;
    flushTimeWheels(form);
    const draft = captureSessionDraft(form);
    keepSessionForm(draft);
    if (target.name === "date") render();
    return;
  }
  if (target.name === "subjectId" && target.form) {
    const subject = state.subjects.find((item) => item.id === target.value);
    const color = resolveColor(subject?.color);
    if (!color) return;
    const radio = target.form.querySelector(`input[name="color"][value="${color}"]`);
    if (radio) radio.checked = true;
  }
});

root.addEventListener("pointerdown", (event) => {
  if (event.pointerType === "mouse" && event.button !== 0) return;
  const hit = event.target.closest("[data-action=nav]");
  if (!hit) return;
  goTab(hit.dataset.tab);
});

root.addEventListener("click", (event) => {
  if (event.target.classList.contains("modal-bg")) {
    closeModal();
    return;
  }
  const hit = event.target.closest("[data-action]");
  if (!hit) return;
  const action = hit.dataset.action;
  event.preventDefault();

  if (action === "close-modal") {
    closeModal();
    return;
  }
  if (action === "nav") {
    goTab(hit.dataset.tab);
    return;
  }
  if (action === "toggle-lists") {
    state.ui.listsOpen = !state.ui.listsOpen;
    render();
    return;
  }
  if (action === "select-list") {
    flushComposer();
    state.ui.selectedListId = hit.dataset.id;
    state.ui.listsOpen = false;
    render();
    return;
  }
  if (action === "add-list") {
    openPrompt("add-list", "新建清单", "例如 学习、工作、生活");
    return;
  }
  if (action === "list-menu") {
    event.stopPropagation();
    state.ui.modal = { type: "list-menu", id: hit.dataset.id };
    render();
    return;
  }
  if (action === "rename-list") {
    const list = state.lists.find((l) => l.id === hit.dataset.id);
    openPrompt("rename-list", "重命名清单", "", list?.name || "");
    state.ui.modal.payload = hit.dataset.id;
    return;
  }
  if (action === "delete-list") {
    openConfirm("delete-list", "删除这个清单？", "清单里的任务会回到收集箱。删除后无法恢复。", "删除", hit.dataset.id);
    return;
  }
  if (action === "add-task" || action === "open-composer") {
    openComposer();
    return;
  }
  if (action === "edit-task") {
    state.ui.modal = { type: "task", taskId: hit.dataset.id };
    render();
    return;
  }
  if (action === "toggle-done") {
    const task = state.tasks.find((t) => t.id === hit.dataset.id);
    if (!task) return;
    task.done = !task.done;
    task.completedAt = task.done ? Date.now() : null;
    pendingToggleId = hit.dataset.id;
    save();
    render();
    return;
  }
  if (action === "delete-task") {
    openConfirm("delete-task", "删除这条任务？", "删除后无法恢复。", "删除", hit.dataset.id);
    return;
  }
  if (action === "subject") {
    if (state.timer.run === "running") return;
    const subject = state.subjects.find((s) => s.id === hit.dataset.id);
    if (!subject) return;
    state.timer.subjectId = subject.id;
    state.timer.subjectName = subject.name;
    if (state.timer.mode === "countdown" && state.timer.kind === "focus") {
      applyTargetSeconds((subject.minutes || state.settings.focusMinutes) * 60);
    }
    save();
    render();
    return;
  }
  if (action === "duration") {
    applyDurationMinutes(currentMinutes() + Number(hit.dataset.delta));
    return;
  }
  if (action === "duration-edit") {
    openPrompt("duration-edit", "设置时长（分钟）", "1 到 180", String(currentMinutes()));
    return;
  }
  if (action === "mode") {
    if (state.timer.run === "running") return;
    const mode = hit.dataset.mode;
    const kind = mode === "countup" ? "focus" : state.timer.kind;
    const prev = state.timer;
    state.timer = idleTimer(mode, kind, kindSeconds(kind), prev.subjectId, prev.subjectName);
    state.timer.taskId = prev.taskId;
    state.timer.taskTitle = prev.taskTitle;
    state.timer.completedFocus = prev.completedFocus;
    save();
    render();
    return;
  }
  if (action === "kind") {
    if (state.timer.run === "running") return;
    const kind = hit.dataset.kind;
    state.timer.kind = kind;
    state.timer.targetSec = kindSeconds(kind);
    state.timer.elapsedSec = 0;
    state.timer.run = "idle";
    state.timer.endAt = null;
    state.timer.startedAt = null;
    save();
    render();
    return;
  }
  if (action === "start") {
    startTimer();
    return;
  }
  if (action === "exit-full") {
    leaveFocusFull();
    save();
    render();
    return;
  }
  if (action === "pause") {
    pauseTimer();
    return;
  }
  if (action === "reset") {
    resetTimer();
    return;
  }
  if (action === "finish-up") {
    finishCountup();
    return;
  }
  if (action === "clear-task") {
    state.timer.taskId = null;
    state.timer.taskTitle = null;
    save();
    render();
    return;
  }
  if (action === "schedule-view") {
    const view = hit.dataset.view;
    if (view !== "day" && view !== "week" && view !== "month") return;
    state.ui.scheduleView = view;
    save();
    render();
    return;
  }
  if (action === "schedule-day") {
    state.ui.scheduleDate = hit.dataset.date;
    state.ui.scheduleView = "day";
    save();
    render();
    return;
  }
  if (action === "schedule-prev") {
    if (scheduleView() === "month") shiftScheduleMonth(-1);
    else shiftScheduleDate(scheduleView() === "week" ? -7 : -1);
    return;
  }
  if (action === "schedule-next") {
    if (scheduleView() === "month") shiftScheduleMonth(1);
    else shiftScheduleDate(scheduleView() === "week" ? 7 : 1);
    return;
  }
  if (action === "schedule-today") {
    state.ui.scheduleDate = dayKey();
    render();
    return;
  }
  if (action === "board-add") {
    if (hit.dataset.date) state.ui.scheduleDate = hit.dataset.date;
    const planId = nearestPlanId(event, hit);
    if (planId) {
      state.ui.modal = { type: "plan", planId };
      render();
      return;
    }
    const rect = hit.getBoundingClientRect();
    const ratio = (event.clientY - rect.top) / Math.max(1, rect.height);
    const startMin = Math.max(
      DAY_START,
      Math.min(DAY_END - 30, snapMinutes(DAY_START + ratio * DAY_SPAN)),
    );
    state.ui.modal = { type: "plan", startMin };
    render();
    return;
  }
  if (action === "add-session") {
    openSessionForm();
    return;
  }
  if (action === "open-session-day") {
    openSessionForm(hit.dataset.date);
    return;
  }
  if (action === "delete-session") {
    const form = hit.closest("form");
    if (form?.dataset.form === "session") flushTimeWheels(form);
    const draft = captureSessionDraft(form);
    if (!removeSessionById(hit.dataset.id)) return;
    save();
    keepSessionForm(draft);
    banner("已删除这条专注");
    render();
    return;
  }
  if (action === "add-plan") {
    state.ui.modal = { type: "plan" };
    render();
    return;
  }
  if (action === "edit-plan") {
    if (hit.dataset.date) state.ui.scheduleDate = hit.dataset.date;
    state.ui.modal = { type: "plan", planId: hit.dataset.id };
    render();
    return;
  }
  if (action === "toggle-plan-check") {
    togglePlanCheck(hit.dataset.id, hit.dataset.date || state.ui.scheduleDate || dayKey());
    return;
  }
  if (action === "delete-plan") {
    const plan = state.plans.find((item) => item.id === hit.dataset.id);
    const repeating = planRepeat(plan) !== "none";
    openConfirm(
      "delete-plan",
      repeating ? "删除这个重复安排？" : "删除这段安排？",
      repeating ? "之后的日子也不会再出现，删除后无法恢复。" : "删除后无法恢复。",
      "删除",
      hit.dataset.id,
    );
    return;
  }
  if (action === "period") {
    const period = hit.dataset.period;
    if (!["day", "week", "month", "year", "all"].includes(period)) return;
    state.ui.statsPeriod = period;
    save();
    render();
    return;
  }
  if (action === "stats-prev" || action === "stats-next") {
    const dir = action === "stats-prev" ? -1 : 1;
    const period = state.ui.statsPeriod;
    const current = state.ui.statsDate || dayKey();
    state.ui.statsDate =
      period === "week"
        ? shiftDayKey(current, { days: 7 * dir })
        : period === "month"
          ? shiftDayKey(current, { months: dir })
          : period === "year"
            ? shiftDayKey(current, { years: dir })
            : shiftDayKey(current, { days: dir });
    save();
    render();
    return;
  }
  if (action === "stats-today") {
    state.ui.statsDate = dayKey();
    save();
    render();
    return;
  }
  if (action === "sync-device") {
    state.settings.syncDevice = hit.dataset.device === "phone" ? "phone" : "tablet";
    saveLocalOnly();
    render();
    return;
  }
  if (action === "recover-ui") {
    lastRenderedTab = "";
    lastSnapshot = { boot: true };
    state.ui.tab = "today";
    state.ui.timerFull = false;
    state.ui.modal = null;
    if (root) root.innerHTML = "";
    render();
    return;
  }
  if (action === "sync-now") {
    if (!cloudToken()) {
      banner("先填写 GitHub 令牌");
      return;
    }
    cloudSync({ silent: false });
    return;
  }
  if (action === "sync-seed-tablet") {
    if (!cloudToken()) {
      banner("先填写 GitHub 令牌");
      return;
    }
    if (!isNativeTablet()) {
      banner("请在平板 App 里覆盖云端");
      return;
    }
    cloudSync({ silent: false, forceTabletSeed: true });
    return;
  }
  if (action === "sync-pull-phone") {
    if (!cloudToken()) {
      banner("先填写 GitHub 令牌");
      return;
    }
    cloudSync({ silent: false, forcePhonePull: true });
    return;
  }
  if (action === "theme") {
    patchSettings({ themeMode: hit.dataset.theme });
    return;
  }
  if (action === "auto-update") {
    const on = hit.dataset.on === "true";
    patchSettings({ autoUpdate: on });
    try {
      window.FocusPad?.setAutoUpdate?.(on);
    } catch (_) {}
    return;
  }
  if (action === "check-update") {
    const url = resolvedUpdateUrl();
    state.settings.updateUrl = url;
    save();
    if (!window.FocusPad?.checkUpdate) {
      banner("热更新只在 App 里可用");
      return;
    }
    try {
      window.FocusPad.setUpdateUrl(url);
      window.FocusPad.setAutoUpdate(true);
      state.ui.updateStatus = "正在检查…";
      render();
      probeRemoteVersion();
      window.FocusPad.checkUpdate();
    } catch (_) {
      banner("检查更新失败");
    }
    return;
  }
  if (action === "step") {
    const key = hit.dataset.key;
    const min = Number(hit.dataset.min);
    const max = Number(hit.dataset.max);
    const next = Math.min(max, Math.max(min, state.settings[key] + Number(hit.dataset.delta)));
    patchSettings({ [key]: next });
    return;
  }
  if (action === "add-subject") {
    state.ui.modal = { type: "subject-form" };
    render();
    return;
  }
  if (action === "rename-subject" || action === "edit-subject") {
    state.ui.modal = { type: "subject-form", subjectId: hit.dataset.id };
    render();
    return;
  }
  if (action === "delete-subject") {
    openConfirm("delete-subject", "删除这个科目？", "历史记录仍会保留这个名称。删除后无法恢复。", "删除", hit.dataset.id);
    return;
  }
  if (action === "load-demo") {
    openConfirm(
      "load-demo",
      "载入示例数据？",
      "会覆盖当前的任务、安排和专注记录，方便审查各个页面。",
      "载入",
    );
    return;
  }
  if (action === "reset-data") {
    if (cloudBusy) {
      banner("同步结束后再清空本地数据");
      return;
    }
    openConfirm("reset-data", "清空全部本地数据？", "这台的任务、安排、专注记录和设置会删除。云端记录仍保留，重新填写令牌可以拉回。", "清空");
    return;
  }
  if (action === "confirm-ok") {
    const modal = state.ui.modal;
    if (!modal) return;
    if (modal.id === "delete-list") {
      const id = modal.payload;
      state.tasks.forEach((t) => {
        if (t.listId === id) t.listId = inboxId();
      });
      rememberTomb("lists", id);
      state.lists = state.lists.filter((l) => l.id !== id || l.system);
      if (state.ui.selectedListId === id) state.ui.selectedListId = inboxId();
    }
    if (modal.id === "delete-task") {
      rememberTomb("tasks", modal.payload);
      state.tasks = state.tasks.filter((t) => t.id !== modal.payload);
    }
    if (modal.id === "delete-plan") {
      rememberTomb("plans", modal.payload);
      state.plans = state.plans.filter((item) => item.id !== modal.payload);
      for (const check of state.planChecks.filter((item) => sameId(item.planId, modal.payload))) {
        rememberTomb("planChecks", check.id);
      }
      state.planChecks = state.planChecks.filter((item) => !sameId(item.planId, modal.payload));
    }
    if (modal.id === "delete-subject") {
      if (state.subjects.length > 1) {
        rememberTomb("subjects", modal.payload);
        state.subjects = state.subjects.filter((s) => s.id !== modal.payload);
        if (state.timer.subjectId === modal.payload) {
          state.timer.subjectId = state.subjects[0].id;
          state.timer.subjectName = state.subjects[0].name;
        }
      }
    }
    if (modal.id === "delete-session") {
      const draft = modal.reopenSession || captureSessionDraft();
      removeSessionById(modal.payload);
      save();
      keepSessionForm({
        date: draft.date || dayKey(),
        startHm: draft.startHm || "09:00",
        endHm: draft.endHm || "09:25",
        subjectId: draft.subjectId || state.subjects[0]?.id || "",
      });
      render();
      return;
    }
    if (modal.id === "load-demo") {
      applyDemoSeed();
      state.ui.selectedListId = "today";
    }
    if (modal.id === "reset-data") {
      if (cloudBusy) {
        finishModal();
        banner("同步结束后再清空本地数据");
        return;
      }
      window.clearTimeout(cloudTimer);
      cloudDirty = false;
      stopTicker();
      state = defaultState();
      state.ui.demoSeeded = DEMO_SEED_VER;
    }
    finishModal();
    save();
    render();
  }
});

root.addEventListener("submit", (event) => {
  const form = event.target.closest("form");
  if (!form) return;
  event.preventDefault();
  const data = new FormData(form);
  if (form.dataset.form === "plan") {
    flushTimeWheels(form);
    const title = String(data.get("title") || "").trim();
    const startMin = parseHm(form.start?.value || data.get("start"));
    let endMin = parseHm(form.end?.value || data.get("end"));
    if (!title) return;
    if (endMin <= startMin) endMin = startMin + 30;
    const subjectId = String(data.get("subjectId") || "");
    const subject = state.subjects.find((item) => item.id === subjectId);
    const existing = form.dataset.id ? state.plans.find((item) => item.id === form.dataset.id) : null;
    let repeat = String(data.get("repeat") || "none");
    if (repeat !== "daily" && repeat !== "weekly") repeat = "none";
    let weekdays = normalizeWeekdays(data.getAll("weekday"));
    if (repeat === "weekly" && !weekdays.length) {
      weekdays = [parseDayKey(state.ui.scheduleDate || dayKey()).getDay()];
    }
    if (repeat === "weekly" && weekdays.length === 7) repeat = "daily";
    if (repeat !== "weekly") weekdays = [];
    const payload = {
      title,
      date: existing?.date || state.ui.scheduleDate || dayKey(),
      startMin,
      endMin,
      subjectId: subject?.id || null,
      subjectName: subject?.name || "",
      color: resolveColor(data.get("color")) || colorOfSubject(subject?.id, subject?.name),
      repeat,
      weekdays,
      commuteBeforeMin: commuteMin(data.get("commuteBefore")),
      commuteAfterMin: commuteMin(data.get("commuteAfter")),
    };
    if (existing) {
      Object.assign(existing, payload);
    } else {
      state.plans.push({ id: uid(), ...payload });
    }
    finishModal();
    save();
    render();
    return;
  }
  if (form.dataset.form === "session") {
    flushTimeWheels(form);
    const subject = state.subjects.find((item) => item.id === String(data.get("subjectId") || ""));
    const dateStr = String(data.get("date") || "").trim();
    const startMin = parseHm(form.start?.value || data.get("start"));
    const endMin = parseHm(form.end?.value || data.get("end"));
    if (!subject) {
      banner("先选一个科目");
      return;
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
      banner("日期不对");
      return;
    }
    if (endMin <= startMin) {
      banner("结束时间要晚于开始");
      return;
    }
    const minutes = Math.min(720, Math.max(1, endMin - startMin));
    const day = parseDayKey(dateStr);
    const startedAt = new Date(
      day.getFullYear(),
      day.getMonth(),
      day.getDate(),
      Math.floor(startMin / 60),
      startMin % 60,
      0,
      0,
    ).getTime();
    const endedAt = startedAt + minutes * 60 * 1000;
    if (Number.isNaN(startedAt) || startedAt > Date.now() || endedAt > Date.now() + 60 * 1000) {
      banner("不能补记还没到的时间");
      return;
    }
    addManualSession(subject, startedAt, minutes * 60);
    if (state.ui.tab === "stats" && state.ui.statsPeriod === "day") {
      state.ui.statsDate = dateStr;
    }
    finishModal();
    save();
    render();
    banner(`已补记 ${formatFocus(minutes * 60)} · ${subject.name}`);
    return;
  }
  if (form.dataset.form === "subject") {
    const name = String(data.get("name") || "").trim();
    const minutes = Math.min(180, Math.max(1, Number(data.get("minutes") || state.settings.focusMinutes)));
    const color = resolveColor(data.get("color")) || nextFreeColor();
    if (!name) return;
    if (form.dataset.id) {
      const subject = state.subjects.find((item) => item.id === form.dataset.id);
      if (subject) {
        subject.name = name;
        subject.minutes = minutes;
        subject.color = color;
      }
      if (state.timer.subjectId === form.dataset.id) state.timer.subjectName = name;
    } else {
      const id = uid();
      state.subjects.push({ id, name, minutes, color });
      if (state.timer.run !== "running") {
        state.timer.subjectId = id;
        state.timer.subjectName = name;
        if (state.timer.mode === "countdown" && state.timer.kind === "focus") {
          applyTargetSeconds(minutes * 60);
        }
      }
    }
    finishModal();
    save();
    render();
    return;
  }
  if (form.dataset.form === "task-quick") {
    commitComposer(form.querySelector("#task-composer"));
    return;
  }
  if (form.dataset.form === "task") {
    const title = String(data.get("title") || "").trim();
    if (!title) return;
    const payload = {
      title,
      note: String(data.get("note") || "").trim(),
      listId: String(data.get("listId") || inboxId()),
      isToday: data.get("isToday") === "on",
    };
    if (form.dataset.id) {
      const task = state.tasks.find((t) => t.id === form.dataset.id);
      if (task) Object.assign(task, payload);
    } else {
      state.tasks.unshift({
        id: uid(),
        done: false,
        createdAt: Date.now(),
        completedAt: null,
        ...payload,
      });
    }
    finishModal();
    save();
    render();
    return;
  }
  const text = String(data.get("text") || "").trim();
  const modal = state.ui.modal;
  if (!text || !modal) return;
  if (modal.id === "add-list") {
    const id = uid();
    state.lists.push({ id, name: text });
    state.ui.selectedListId = id;
  }
  if (modal.id === "rename-list") {
    const list = state.lists.find((l) => l.id === modal.payload);
    if (list && !list.system) list.name = text;
  }
  if (modal.id === "duration-edit") {
    finishModal();
    applyDurationMinutes(Number(text));
    return;
  }
  if (modal.id === "add-subject") {
    const minutes = state.settings.focusMinutes;
    const id = uid();
    state.subjects.push({ id, name: text, minutes, color: nextFreeColor() });
    if (state.timer.run !== "running") {
      state.timer.subjectId = id;
      state.timer.subjectName = text;
    }
  }
  if (modal.id === "rename-subject") {
    const subject = state.subjects.find((s) => s.id === modal.payload);
    if (subject) subject.name = text;
    if (state.timer.subjectId === modal.payload) state.timer.subjectName = text;
  }
  finishModal();
  save();
  render();
});

document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible") {
    if (state.timer.run === "running") {
      if (state.timer.mode === "countdown" && remaining() <= 0) finishCountdown();
      else startTicker();
    }
    refreshOnOpen();
  }
});

function refreshOnOpen() {
  if (!cloudToken()) {
    state.ui.syncStatus = "这台还没填 GitHub 令牌，云端记录拉不下来";
    if (isNativeApp()) banner(state.ui.syncStatus);
    if (state.ui.tab === "settings") render();
  } else {
    cloudSync({ silent: true });
  }
  try {
    if (window.FocusPad?.setUpdateUrl) window.FocusPad.setUpdateUrl(resolvedUpdateUrl());
    if (window.FocusPad?.setAutoUpdate) window.FocusPad.setAutoUpdate(true);
    if (window.FocusPad?.checkUpdateSilent) window.FocusPad.checkUpdateSilent();
  } catch (_) {}
}

function syncUpdateBridge() {
  try {
    if (!window.FocusPad?.setUpdateUrl) return;
    window.FocusPad.setUpdateUrl(resolvedUpdateUrl());
    window.FocusPad.setAutoUpdate(true);
  } catch (_) {}
}

try {
  rememberRecordCores();
  applyTheme();
  syncUpdateBridge();
  if (state.timer.run === "running" && state.timer.kind === "focus") {
    state.ui.timerFull = true;
  }
  if (state.timer.run === "running") {
    if (state.timer.mode === "countdown" && remaining() <= 0) finishCountdown();
    else startTicker();
  }
  syncKeepAwake();
  render();
  if (state.ui.timerFull) setImmersive(true);
  refreshOnOpen();
} catch (error) {
  console.error(error);
  if (root) {
    root.innerHTML = `<main class="page" style="padding:24px"><h1>开屏出错</h1><p class="muted">${esc(String(error && error.message ? error.message : error))}</p></main>`;
  }
}
